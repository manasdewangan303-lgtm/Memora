import unittest
import os
import sys

# Add parent directory to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.database import init_db, query_one, query_all
from app.seed_data import seed_demo_data
from app.adaptive_engine import evaluate_session_adaptation, compute_cognitive_overview

class TestMemoraBackend(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        init_db()
        seed_demo_data()

    def test_database_seeded_correctly(self):
        patient = query_one("SELECT * FROM patients WHERE full_name = 'Mrs. Sharma'")
        self.assertIsNotNone(patient)
        self.assertEqual(patient["age"], 72)
        
        caregiver = query_one("SELECT * FROM caregivers WHERE full_name = 'Mr. Sharma'")
        self.assertIsNotNone(caregiver)

        reminders = query_all("SELECT * FROM reminders WHERE patient_id = ?", (patient["id"],))
        self.assertGreaterEqual(len(reminders), 4)

        memories = query_all("SELECT * FROM memories WHERE patient_id = ?", (patient["id"],))
        self.assertGreaterEqual(len(memories), 2)

    def test_adaptive_engine_step_up(self):
        # Scenario from SIH spec: Patient performs Memory Match at Level 2, Accuracy = 90% -> Increase to Level 3
        res = evaluate_session_adaptation(
            current_level=2,
            accuracy=90.0,
            response_time_ms=4500,
            mistakes=0
        )
        self.assertEqual(res["next_level"], 3)
        self.assertIn("Difficulty increased", res["explanation"])
        self.assertIn("Level 3", res["explanation"])

    def test_adaptive_engine_maintain(self):
        # Accuracy 70% -> Maintain Level 2
        res = evaluate_session_adaptation(
            current_level=2,
            accuracy=70.0,
            response_time_ms=6200,
            mistakes=1
        )
        self.assertEqual(res["next_level"], 2)
        self.assertIn("maintained", res["explanation"])

    def test_adaptive_engine_step_down(self):
        # Accuracy 40% -> Reduce Level 2 to Level 1
        res = evaluate_session_adaptation(
            current_level=2,
            accuracy=40.0,
            response_time_ms=15000,
            mistakes=3
        )
        self.assertEqual(res["next_level"], 1)
        self.assertIn("adjusted", res["explanation"])
        # Verify strict non-diagnostic neutral language
        self.assertNotIn("worse", res["explanation"].lower())
        self.assertNotIn("dementia", res["explanation"].lower())

    def test_cognitive_overview_aggregation(self):
        sessions = [
            {"game_type": "memory_match", "accuracy": 85.0, "response_time_ms": 5000},
            {"game_type": "sequence_recall", "accuracy": 70.0, "response_time_ms": 6000},
            {"game_type": "object_recognition", "accuracy": 90.0, "response_time_ms": 4000}
        ]
        overview = compute_cognitive_overview(sessions)
        self.assertEqual(overview["memory"], 85.0)
        self.assertEqual(overview["sequence"], 70.0)
        self.assertEqual(overview["recognition"], 90.0)
        self.assertGreater(overview["attention"], 60.0)

if __name__ == "__main__":
    unittest.main()
