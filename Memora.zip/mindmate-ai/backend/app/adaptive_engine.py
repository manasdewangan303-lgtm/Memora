"""
MEMORA - Transparent Explainable Adaptive Cognitive Engine

SAFETY NOTICE:
This module contains rule-based cognitive adaptation algorithms.
It strictly DOES NOT diagnose dementia, determine clinical severity,
or replace qualified healthcare assessment. All terminology is non-diagnostic.
"""

from typing import Dict, Any, List

def evaluate_session_adaptation(
    current_level: int,
    accuracy: float,
    response_time_ms: int,
    mistakes: int,
    recent_sessions: List[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Evaluates patient cognitive game performance and decides next difficulty level
    with an explainable, transparent rationale for caregivers.
    
    Difficulty Levels: 1 to 4
    Level 1: 3 items (Introductory / gentle recall)
    Level 2: 4 items (Moderate cognitive challenge)
    Level 3: 5 items (Advanced cognitive stimulation)
    Level 4: 6 items (High cognitive stimulation)
    """
    recent_sessions = recent_sessions or []
    
    # Baseline constraints
    min_level = 1
    max_level = 4
    
    # Calculate rolling recent accuracy if past sessions exist
    all_accuracies = [s.get("accuracy", 0.0) for s in recent_sessions[-3:]] + [accuracy]
    avg_recent_accuracy = sum(all_accuracies) / len(all_accuracies)
    
    # Response time factor: under 6000ms is considered prompt for elderly recall
    is_prompt_response = response_time_ms < 6500
    is_hesitant_response = response_time_ms > 14000
    
    next_level = current_level
    explanation = ""
    trend_summary = ""
    
    # Rule 1: High Accuracy (> 85%) & Prompt Response -> Step Up Difficulty
    if accuracy >= 85.0 and mistakes <= 1:
        if current_level < max_level:
            next_level = current_level + 1
            explanation = (
                f"Difficulty increased from Level {current_level} to Level {next_level} "
                f"due to consistently strong accuracy ({accuracy:.0f}%) and confident response time ({(response_time_ms/1000):.1f}s)."
            )
            trend_summary = "Performance showed high engagement and confidence; difficulty stepped up gradually."
        else:
            next_level = max_level
            explanation = (
                f"Maintained at maximum Level {max_level} with outstanding accuracy ({accuracy:.0f}%). "
                f"Patient is demonstrating peak session engagement."
            )
            trend_summary = "Consistently high performance maintained at top tier."
            
    # Rule 2: Moderate Accuracy (50% - 84%) -> Maintain Current Difficulty
    elif 50.0 <= accuracy < 85.0:
        next_level = current_level
        explanation = (
            f"Difficulty maintained at Level {current_level} (Accuracy: {accuracy:.0f}%, Mistakes: {mistakes}). "
            f"Reinforcing comfortable recognition and memory retention."
        )
        trend_summary = "Stable session performance; maintaining current level to build familiarity."
        
    # Rule 3: Challenging Session (< 50% Accuracy OR high mistakes / long latency) -> Step Down Difficulty
    else:
        if current_level > min_level:
            next_level = current_level - 1
            explanation = (
                f"Difficulty adjusted from Level {current_level} to Level {next_level} "
                f"to support comfortable recall and avoid fatigue (Recent accuracy: {accuracy:.0f}%)."
            )
            trend_summary = "Difficulty softened to preserve positive user experience and reduce cognitive fatigue."
        else:
            next_level = min_level
            explanation = (
                f"Maintained at foundational Level {min_level} with gentle pacing and hints enabled "
                f"to ensure stress-free participation."
            )
            trend_summary = "Foundational level active with supportive prompts."

    return {
        "previous_level": current_level,
        "next_level": next_level,
        "accuracy": round(accuracy, 1),
        "response_time_ms": response_time_ms,
        "mistakes": mistakes,
        "avg_recent_accuracy": round(avg_recent_accuracy, 1),
        "explanation": explanation,
        "trend_summary": trend_summary
    }

def compute_cognitive_overview(sessions: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Aggregates session metrics into cognitive activity domains:
    - Memory: Memory Match recall rate
    - Attention: Average speed and low error rate across activities
    - Sequence: Sequence recall ordering accuracy
    - Recognition: Object recognition accuracy
    
    Terminology strictly avoids diagnostic claims.
    """
    if not sessions:
        return {
            "memory": 80.0,
            "attention": 75.0,
            "sequence": 70.0,
            "recognition": 85.0,
            "overall_accuracy": 77.5,
            "total_sessions": 0
        }
        
    memory_scores = [s["accuracy"] for s in sessions if s.get("game_type") == "memory_match"]
    sequence_scores = [s["accuracy"] for s in sessions if s.get("game_type") == "sequence_recall"]
    recog_scores = [s["accuracy"] for s in sessions if s.get("game_type") == "object_recognition"]
    all_scores = [s["accuracy"] for s in sessions]
    
    def avg_or(scores, default):
        return round(sum(scores) / len(scores), 1) if scores else default

    memory_avg = avg_or(memory_scores, 82.0)
    sequence_avg = avg_or(sequence_scores, 68.0)
    recog_avg = avg_or(recog_scores, 88.0)
    
    # Attention index derived from average accuracy penalized gently by response latency (> 8000ms)
    attention_samples = []
    for s in sessions:
        acc = s.get("accuracy", 70.0)
        rt = s.get("response_time_ms", 5000)
        latency_penalty = min(20.0, max(0.0, (rt - 6000) / 400.0))
        attention_samples.append(max(40.0, acc - latency_penalty))
    attention_avg = round(sum(attention_samples) / len(attention_samples), 1) if attention_samples else 74.0

    return {
        "memory": memory_avg,
        "attention": attention_avg,
        "sequence": sequence_avg,
        "recognition": recog_avg,
        "overall_accuracy": round(sum(all_scores) / len(all_scores), 1),
        "total_sessions": len(sessions)
    }
