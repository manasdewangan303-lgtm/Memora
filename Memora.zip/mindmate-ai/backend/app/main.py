import os
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse

from app.config import PROJECT_NAME, PROJECT_TAGLINE, PROBLEM_STATEMENT, FRONTEND_DIR
from app.database import init_db
from app.seed_data import seed_demo_data
from app.routers import (
    auth_router,
    patient_router,
    games_router,
    reminders_router,
    memories_router,
    gps_router,
    sync_router,
    dashboard_router
)

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Initialize DB & Seed demo data on startup
    init_db()
    seed_demo_data()
    yield

app = FastAPI(
    title=PROJECT_NAME,
    description=f"{PROJECT_TAGLINE} | {PROBLEM_STATEMENT}",
    version="1.0.0",
    lifespan=lifespan
)

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API Routers
api_prefix = "/api"
app.include_router(auth_router.router, prefix=api_prefix)
app.include_router(patient_router.router, prefix=api_prefix)
app.include_router(games_router.router, prefix=api_prefix)
app.include_router(reminders_router.router, prefix=api_prefix)
app.include_router(memories_router.router, prefix=api_prefix)
app.include_router(gps_router.router, prefix=api_prefix)
app.include_router(sync_router.router, prefix=api_prefix)
app.include_router(dashboard_router.router, prefix=api_prefix)

@app.get("/health")
def health_check():
    return {
        "status": "online",
        "app": PROJECT_NAME,
        "tagline": PROJECT_TAGLINE,
        "problem_statement": PROBLEM_STATEMENT,
        "medical_safety_notice": "Strictly non-diagnostic cognitive supportive system. Game metrics are used solely for adaptive difficulty and caregiver overview."
    }

# Mount Frontend Static Assets
if FRONTEND_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(FRONTEND_DIR)), name="static")

    @app.get("/")
    async def serve_index():
        index_file = FRONTEND_DIR / "index.html"
        if index_file.exists():
            return FileResponse(str(index_file))
        return JSONResponse({"message": f"{PROJECT_NAME} backend running. Frontend index.html not yet built."})
