import sqlite3
from typing import Any, Dict, List, Optional
from app.config import DB_PATH

def get_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    conn = get_connection()
    cursor = conn.cursor()
    
    # 1. Users Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        username TEXT UNIQUE NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('patient', 'caregiver', 'healthcare_worker', 'admin')),
        full_name TEXT NOT NULL,
        password_hash TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """)

    # 2. Caregivers Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS caregivers (
        id TEXT PRIMARY KEY,
        user_id TEXT UNIQUE NOT NULL,
        full_name TEXT NOT NULL,
        phone TEXT,
        relationship TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    """)

    # 3. Patients Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS patients (
        id TEXT PRIMARY KEY,
        user_id TEXT UNIQUE NOT NULL,
        caregiver_id TEXT,
        full_name TEXT NOT NULL,
        age INTEGER NOT NULL,
        emergency_contact TEXT,
        home_latitude REAL,
        home_longitude REAL,
        home_address TEXT,
        current_level INTEGER DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (caregiver_id) REFERENCES caregivers(id) ON DELETE SET NULL
    );
    """)

    # 4. Game Sessions & Results Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS game_sessions (
        id TEXT PRIMARY KEY,
        patient_id TEXT NOT NULL,
        game_type TEXT NOT NULL CHECK(game_type IN ('memory_match', 'sequence_recall', 'object_recognition')),
        difficulty_level INTEGER NOT NULL,
        score INTEGER NOT NULL,
        accuracy REAL NOT NULL,
        response_time_ms INTEGER NOT NULL,
        mistakes INTEGER NOT NULL,
        items_count INTEGER NOT NULL,
        feedback_text TEXT,
        sync_status TEXT DEFAULT 'synced',
        client_id TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE
    );
    """)

    # 5. Reminders Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS reminders (
        id TEXT PRIMARY KEY,
        patient_id TEXT NOT NULL,
        title TEXT NOT NULL,
        category TEXT NOT NULL CHECK(category IN ('medicine', 'hydration', 'activity', 'appointment')),
        scheduled_time TEXT NOT NULL,
        is_completed INTEGER DEFAULT 0,
        frequency TEXT DEFAULT 'Daily',
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE
    );
    """)

    # 6. Personal Memories Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS memories (
        id TEXT PRIMARY KEY,
        patient_id TEXT NOT NULL,
        person_name TEXT NOT NULL,
        relationship TEXT NOT NULL,
        description TEXT NOT NULL,
        photo_url TEXT,
        hint TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE
    );
    """)

    # 7. GPS Locations History Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS gps_locations (
        id TEXT PRIMARY KEY,
        patient_id TEXT NOT NULL,
        latitude REAL NOT NULL,
        longitude REAL NOT NULL,
        accuracy_m REAL DEFAULT 10.0,
        recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        sync_status TEXT DEFAULT 'synced',
        FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE
    );
    """)

    # 8. Caregiver Alerts Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS caregiver_alerts (
        id TEXT PRIMARY KEY,
        patient_id TEXT NOT NULL,
        alert_type TEXT NOT NULL,
        message TEXT NOT NULL,
        severity TEXT DEFAULT 'warning' CHECK(severity IN ('info', 'warning', 'critical')),
        is_read INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE
    );
    """)

    # 9. Sync Queue Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS sync_queue (
        id TEXT PRIMARY KEY,
        client_uuid TEXT UNIQUE NOT NULL,
        entity_type TEXT NOT NULL,
        payload_json TEXT NOT NULL,
        status TEXT DEFAULT 'synced',
        received_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """)

    conn.commit()
    conn.close()

def query_all(query: str, params: tuple = ()) -> List[Dict[str, Any]]:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(query, params)
    rows = cursor.fetchall()
    result = [dict(row) for row in rows]
    conn.close()
    return result

def query_one(query: str, params: tuple = ()) -> Optional[Dict[str, Any]]:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(query, params)
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None

def execute_write(query: str, params: tuple = ()) -> int:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(query, params)
    conn.commit()
    rowcount = cursor.rowcount
    conn.close()
    return rowcount
