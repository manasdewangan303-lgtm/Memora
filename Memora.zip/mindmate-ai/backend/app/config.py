import os
from pathlib import Path

# Base Paths
BASE_DIR = Path(__file__).resolve().parent.parent
PROJECT_DIR = BASE_DIR.parent
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)
# Database with backward compatibility migration
OLD_DB_PATH = DATA_DIR / "mindmate.db"
NEW_DB_PATH = DATA_DIR / "memora.db"
if OLD_DB_PATH.exists() and not NEW_DB_PATH.exists():
    try:
        import shutil
        shutil.copy2(OLD_DB_PATH, NEW_DB_PATH)
    except Exception:
        pass

DB_PATH = NEW_DB_PATH if NEW_DB_PATH.exists() else OLD_DB_PATH
FRONTEND_DIR = PROJECT_DIR / "frontend"

# Security & Authentication
JWT_SECRET_KEY = os.getenv("MEMORA_JWT_SECRET", os.getenv("MINDMATE_JWT_SECRET", "memora-sih-2026-super-secret-key-ner-accessibility"))
JWT_ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24 * 7  # 7 days for ease during demo

# Project Details
PROJECT_NAME = "MEMORA"
PROJECT_TAGLINE = "AI that adapts to the person — not the other way around."
PROBLEM_STATEMENT = "SIH26003 – AI-Based Cognitive Gaming and Memory Assistance Platform for Elderly Dementia Patients"

# Demo Defaults
DEFAULT_PATIENT_NAME = "Mrs. Sharma"
DEFAULT_PATIENT_AGE = 72
DEFAULT_CAREGIVER_NAME = "Mr. Sharma"
# Guwahati, Assam (North-Eastern Region anchor coordinate for SIH regional focus)
DEFAULT_HOME_LAT = 26.1445
DEFAULT_HOME_LNG = 91.7362
DEFAULT_HOME_ADDRESS = "House #14, B.R. Phukan Road, Bharalumukh, Guwahati, Assam"
