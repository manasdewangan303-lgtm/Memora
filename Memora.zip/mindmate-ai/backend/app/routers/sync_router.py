import json
import uuid
from datetime import datetime, timezone
from fastapi import APIRouter
from app.database import query_one, execute_write
from app.schemas import SyncBatchRequest, SyncBatchResponse
from app.adaptive_engine import evaluate_session_adaptation

router = APIRouter(prefix="/sync", tags=["Offline Synchronization"])

@router.post("", response_model=SyncBatchResponse)
def synchronize_batch(batch: SyncBatchRequest):
    synced_ids = []
    now_str = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")

    for item in batch.items:
        # Check idempotency in sync_queue
        existing = query_one("SELECT id FROM sync_queue WHERE client_uuid = ?", (item.client_uuid,))
        if existing:
            synced_ids.append(item.client_uuid)
            continue

        payload = item.payload
        patient_id = payload.get("patient_id", "patient_demo_1")

        if item.entity_type == "game_session":
            # Avoid duplicate game session insert
            sess_check = query_one("SELECT id FROM game_sessions WHERE id = ? OR client_id = ?", 
                                   (item.client_uuid, item.client_uuid))
            if not sess_check:
                diff = int(payload.get("difficulty_level", 1))
                acc = float(payload.get("accuracy", 80.0))
                rt = int(payload.get("response_time_ms", 5000))
                mistakes = int(payload.get("mistakes", 0))
                items_cnt = int(payload.get("items_count", 3))
                score = int(payload.get("score", 80))
                gtype = payload.get("game_type", "memory_match")
                dt = payload.get("timestamp", now_str)

                # Run adaptive evaluation
                eval_res = evaluate_session_adaptation(
                    current_level=diff,
                    accuracy=acc,
                    response_time_ms=rt,
                    mistakes=mistakes
                )

                execute_write("""
                    INSERT INTO game_sessions (
                        id, patient_id, game_type, difficulty_level, score, accuracy,
                        response_time_ms, mistakes, items_count, feedback_text, sync_status, created_at, client_id
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'synced', ?, ?)
                """, (
                    item.client_uuid, patient_id, gtype, diff, score, acc,
                    rt, mistakes, items_cnt, eval_res["explanation"], dt, item.client_uuid
                ))

                # Update patient current level if increased
                if eval_res["next_level"] > diff:
                    execute_write("UPDATE patients SET current_level = ? WHERE id = ?", 
                                  (eval_res["next_level"], patient_id))

        elif item.entity_type == "gps_ping":
            lat = payload.get("latitude")
            lng = payload.get("longitude")
            dt = payload.get("timestamp", now_str)
            if lat is not None and lng is not None:
                execute_write("""
                    INSERT INTO gps_locations (id, patient_id, latitude, longitude, accuracy_m, recorded_at, sync_status)
                    VALUES (?, ?, ?, ?, 10.0, ?, 'synced')
                """, (item.client_uuid, patient_id, lat, lng, dt))

        elif item.entity_type == "reminder_status":
            rem_id = payload.get("reminder_id")
            is_comp = int(payload.get("is_completed", 1))
            if rem_id:
                execute_write("UPDATE reminders SET is_completed = ? WHERE id = ?", (is_comp, rem_id))

        # Record receipt in sync queue
        execute_write("""
            INSERT INTO sync_queue (id, client_uuid, entity_type, payload_json, status, received_at)
            VALUES (?, ?, ?, ?, 'synced', ?)
        """, (str(uuid.uuid4()), item.client_uuid, item.entity_type, json.dumps(payload), now_str))

        synced_ids.append(item.client_uuid)

    return SyncBatchResponse(
        synced_count=len(synced_ids),
        status="success",
        synced_ids=synced_ids
    )
