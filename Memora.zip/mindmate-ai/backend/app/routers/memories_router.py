import uuid
import random
from datetime import datetime, timezone
from fastapi import APIRouter, HTTPException
from app.database import query_all, query_one, execute_write
from app.schemas import MemoryCreate

router = APIRouter(prefix="/memories", tags=["Personal Memories"])

@router.get("/{patient_id}")
def get_memories(patient_id: str):
    memories = query_all("""
        SELECT * FROM memories
        WHERE patient_id = ?
        ORDER BY created_at DESC
    """, (patient_id,))
    return memories

@router.post("")
def add_memory(data: MemoryCreate):
    patient = query_one("SELECT id FROM patients WHERE id = ?", (data.patient_id,))
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    new_id = str(uuid.uuid4())
    now_str = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")

    execute_write("""
        INSERT INTO memories (id, patient_id, person_name, relationship, description, photo_url, hint, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        new_id, data.patient_id, data.person_name, data.relationship,
        data.description, data.photo_url or "avatar_default.png",
        data.hint, now_str
    ))

    return query_one("SELECT * FROM memories WHERE id = ?", (new_id,))

@router.get("/{patient_id}/activity")
def get_memory_activity(patient_id: str):
    """
    Generates a gentle personal memory recall question for the patient.
    Safety notice: Strictly for positive familiarity; does not score or diagnose dementia.
    """
    memories = query_all("SELECT * FROM memories WHERE patient_id = ?", (patient_id,))
    if not memories:
        return {
            "has_memory": False,
            "message": "No personalized memories added yet. Caregiver can add family members anytime."
        }

    target = random.choice(memories)
    correct_option = f"{target['person_name']} — {target['relationship']}"
    
    # Create plausible alternative options
    other_names = [m for m in memories if m["id"] != target["id"]]
    options = [correct_option]
    for other in other_names[:2]:
        options.append(f"{other['person_name']} — {other['relationship']}")
        
    fallback_options = ["Dr. Barua — Family Physician", "Mr. Sharma — Spouse", "Neighbor Anita"]
    for fb in fallback_options:
        if len(options) >= 3:
            break
        if fb not in options:
            options.append(fb)

    random.shuffle(options)

    return {
        "has_memory": True,
        "memory_id": target["id"],
        "person_name": target["person_name"],
        "relationship": target["relationship"],
        "description": target["description"],
        "hint": target.get("hint") or f"Someone very close to you ({target['relationship']})",
        "photo_url": target.get("photo_url"),
        "question": f"Do you recognize this person?",
        "options": options,
        "correct_option": correct_option
    }

@router.delete("/{memory_id}")
def delete_memory(memory_id: str):
    execute_write("DELETE FROM memories WHERE id = ?", (memory_id,))
    return {"status": "success", "deleted_id": memory_id}
