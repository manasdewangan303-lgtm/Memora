from datetime import datetime, timezone
from fastapi import APIRouter, HTTPException
from app.database import query_all, query_one
from app.adaptive_engine import compute_cognitive_overview, evaluate_session_adaptation

router = APIRouter(prefix="/dashboard", tags=["Caregiver Dashboard"])

@router.get("/{patient_id}")
def get_caregiver_dashboard(patient_id: str):
    patient = query_one("SELECT * FROM patients WHERE id = ?", (patient_id,))
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    # Game sessions for trends
    sessions = query_all("""
        SELECT * FROM game_sessions
        WHERE patient_id = ?
        ORDER BY created_at DESC
        LIMIT 14
    """, (patient_id,))

    # Today's sessions
    today_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    today_sessions = [s for s in sessions if s["created_at"].startswith(today_str)]

    # Compute cognitive domain breakdown
    cognitive_overview = compute_cognitive_overview(sessions)

    # Reminders
    reminders = query_all("""
        SELECT * FROM reminders
        WHERE patient_id = ?
        ORDER BY is_completed ASC, scheduled_time ASC
    """, (patient_id,))

    # Caregiver Alerts
    alerts = query_all("""
        SELECT * FROM caregiver_alerts
        WHERE patient_id = ?
        ORDER BY created_at DESC
        LIMIT 10
    """, (patient_id,))

    # Explainable AI status
    last_session = sessions[0] if sessions else None
    if last_session:
        eval_res = evaluate_session_adaptation(
            current_level=patient["current_level"],
            accuracy=last_session["accuracy"],
            response_time_ms=last_session["response_time_ms"],
            mistakes=last_session["mistakes"],
            recent_sessions=sessions[1:5]
        )
        adaptive_explanation = eval_res["explanation"]
        trend_summary = eval_res["trend_summary"]
    else:
        adaptive_explanation = f"Patient is active at Level {patient['current_level']}. Consistent daily cognitive stimulation recommended."
        trend_summary = "Pacing set to gentle introductory recall."

    # Trends format (oldest to newest for Chart.js)
    recent_trend = list(reversed(sessions[:7]))

    # Last active time
    last_active_time = sessions[0]["created_at"] if sessions else "Earlier today"

    # Overall accuracy
    overall_acc = cognitive_overview.get("overall_accuracy", 80.0)

    return {
        "patient": {
            "id": patient["id"],
            "full_name": patient["full_name"],
            "age": patient["age"],
            "status": "Active",
            "current_level": patient["current_level"],
            "emergency_contact": patient["emergency_contact"],
            "home_address": patient.get("home_address"),
            "home_latitude": patient.get("home_latitude"),
            "home_longitude": patient.get("home_longitude")
        },
        "today_sessions_count": len(today_sessions),
        "overall_accuracy": overall_acc,
        "last_active_time": last_active_time,
        "cognitive_overview": cognitive_overview,
        "recent_trend": recent_trend,
        "active_reminders": reminders,
        "alerts": alerts,
        "adaptive_status": {
            "current_level": patient["current_level"],
            "explanation": adaptive_explanation,
            "trend_summary": trend_summary
        }
    }
