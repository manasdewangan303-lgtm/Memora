from fastapi import APIRouter, HTTPException, Depends
from typing import List
from app.database import query_all, query_one, execute_write
from app.schemas import PatientResponse

router = APIRouter(prefix="/patients", tags=["Patients"])

@router.get("", response_model=List[PatientResponse])
def get_all_patients():
    patients = query_all("SELECT * FROM patients ORDER BY full_name")
    return [PatientResponse(**p) for p in patients]

@router.get("/{patient_id}", response_model=PatientResponse)
def get_patient(patient_id: str):
    patient = query_one("SELECT * FROM patients WHERE id = ?", (patient_id,))
    if not patient:
        raise HTTPException(status_code=404, detail="Patient record not found")
    return PatientResponse(**patient)

@router.put("/{patient_id}")
def update_patient(patient_id: str, payload: dict):
    existing = query_one("SELECT * FROM patients WHERE id = ?", (patient_id,))
    if not existing:
        raise HTTPException(status_code=404, detail="Patient not found")

    full_name = payload.get("full_name", existing["full_name"])
    age = payload.get("age", existing["age"])
    emergency_contact = payload.get("emergency_contact", existing["emergency_contact"])
    home_address = payload.get("home_address", existing["home_address"])
    current_level = payload.get("current_level", existing["current_level"])

    execute_write("""
        UPDATE patients
        SET full_name = ?, age = ?, emergency_contact = ?, home_address = ?, current_level = ?
        WHERE id = ?
    """, (full_name, age, emergency_contact, home_address, current_level, patient_id))

    updated = query_one("SELECT * FROM patients WHERE id = ?", (patient_id,))
    return {"status": "success", "patient": updated}
