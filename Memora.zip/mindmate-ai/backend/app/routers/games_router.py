import uuid
from datetime import datetime, timezone
from fastapi import APIRouter, HTTPException
from typing import List, Dict, Any
from app.database import query_all, query_one, execute_write
from app.schemas import GameSessionCreate, AdaptiveEvaluationResponse
from app.adaptive_engine import evaluate_session_adaptation, compute_cognitive_overview

router = APIRouter(prefix="/game-results", tags=["Cognitive Games & Adaptive AI"])

@router.post("", response_model=AdaptiveEvaluationResponse)
def submit_game_result(data: GameSessionCreate):
    patient = query_one("SELECT * FROM patients WHERE id = ?", (data.patient_id,))
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    # Fetch recent sessions for rolling trend calculation
    recent_sessions = query_all("""
        SELECT * FROM game_sessions
        WHERE patient_id = ?
        ORDER BY created_at DESC
        LIMIT 5
    """, (data.patient_id,))

    # Evaluate Adaptive AI recommendation
    eval_result = evaluate_session_adaptation(
        current_level=data.difficulty_level,
        accuracy=data.accuracy,
        response_time_ms=data.response_time_ms,
        mistakes=data.mistakes,
        recent_sessions=recent_sessions
    )

    session_id = data.client_id or str(uuid.uuid4())
    now_str = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")

    # Record the session
    execute_write("""
        INSERT INTO game_sessions (
            id, patient_id, game_type, difficulty_level, score, accuracy,
            response_time_ms, mistakes, items_count, feedback_text, sync_status, created_at, client_id
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'synced', ?, ?)
    """, (
        session_id, data.patient_id, data.game_type, data.difficulty_level,
        data.score, data.accuracy, data.response_time_ms, data.mistakes,
        data.items_count, data.feedback_text or eval_result["trend_summary"],
        now_str, data.client_id
    ))

    # Update patient's current difficulty level if changed
    next_level = eval_result["next_level"]
    if next_level != patient["current_level"]:
        execute_write("UPDATE patients SET current_level = ? WHERE id = ?", (next_level, data.patient_id))

    # Check if a supportive alert should be posted to the caregiver
    if data.accuracy < 50.0:
        alert_msg = f"Please review: Recent cognitive activity performance decreased ({data.accuracy:.0f}% on {data.game_type.replace('_', ' ').title()}). Difficulty was softly stepped down to Level {next_level}."
        execute_write("""
            INSERT INTO caregiver_alerts (id, patient_id, alert_type, message, severity, is_read, created_at)
            VALUES (?, ?, 'Cognitive Activity Update', ?, 'info', 0, ?)
        """, (str(uuid.uuid4()), data.patient_id, alert_msg, now_str))

    return AdaptiveEvaluationResponse(
        patient_id=data.patient_id,
        game_type=data.game_type,
        previous_level=data.difficulty_level,
        next_level=next_level,
        accuracy=data.accuracy,
        response_time_ms=data.response_time_ms,
        mistakes=data.mistakes,
        explanation=eval_result["explanation"],
        trend_summary=eval_result["trend_summary"],
        session_id=session_id
    )

@router.get("/patients/{patient_id}")
def get_patient_game_results(patient_id: str, limit: int = 20):
    sessions = query_all("""
        SELECT * FROM game_sessions
        WHERE patient_id = ?
        ORDER BY created_at DESC
        LIMIT ?
    """, (patient_id, limit))
    return sessions

@router.get("/patients/{patient_id}/adaptive-status")
def get_patient_adaptive_status(patient_id: str):
    patient = query_one("SELECT * FROM patients WHERE id = ?", (patient_id,))
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    sessions = query_all("""
        SELECT * FROM game_sessions
        WHERE patient_id = ?
        ORDER BY created_at DESC
        LIMIT 10
    """, (patient_id,))

    overview = compute_cognitive_overview(sessions)
    last_session = sessions[0] if sessions else None

    current_level = patient["current_level"]
    if last_session:
        eval_result = evaluate_session_adaptation(
            current_level=current_level,
            accuracy=last_session["accuracy"],
            response_time_ms=last_session["response_time_ms"],
            mistakes=last_session["mistakes"],
            recent_sessions=sessions[1:]
        )
        explanation = eval_result["explanation"]
    else:
        explanation = f"Active at baseline Level {current_level}. Ready for cognitive stimulation."

    return {
        "patient_id": patient_id,
        "current_level": current_level,
        "explanation": explanation,
        "cognitive_overview": overview,
        "last_session": last_session
    }
