import uuid
from datetime import datetime, timezone
from fastapi import APIRouter, HTTPException
from typing import List
from app.database import query_all, query_one, execute_write
from app.schemas import ReminderCreate, ReminderUpdate

router = APIRouter(prefix="/reminders", tags=["Reminders"])

@router.get("/{patient_id}")
def get_reminders(patient_id: str):
    reminders = query_all("""
        SELECT * FROM reminders
        WHERE patient_id = ?
        ORDER BY is_completed ASC, scheduled_time ASC
    """, (patient_id,))
    return reminders

@router.post("")
def create_reminder(data: ReminderCreate):
    patient = query_one("SELECT id FROM patients WHERE id = ?", (data.patient_id,))
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    new_id = str(uuid.uuid4())
    now_str = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")

    execute_write("""
        INSERT INTO reminders (id, patient_id, title, category, scheduled_time, is_completed, frequency, notes, created_at)
        VALUES (?, ?, ?, ?, ?, 0, ?, ?, ?)
    """, (new_id, data.patient_id, data.title, data.category, data.scheduled_time, data.frequency, data.notes, now_str))

    return query_one("SELECT * FROM reminders WHERE id = ?", (new_id,))

@router.patch("/{reminder_id}/toggle")
def toggle_reminder(reminder_id: str):
    rem = query_one("SELECT * FROM reminders WHERE id = ?", (reminder_id,))
    if not rem:
        raise HTTPException(status_code=404, detail="Reminder not found")

    new_status = 0 if rem["is_completed"] == 1 else 1
    execute_write("UPDATE reminders SET is_completed = ? WHERE id = ?", (new_status, reminder_id))
    return {"status": "success", "reminder_id": reminder_id, "is_completed": new_status}

@router.delete("/{reminder_id}")
def delete_reminder(reminder_id: str):
    execute_write("DELETE FROM reminders WHERE id = ?", (reminder_id,))
    return {"status": "success", "deleted_id": reminder_id}
