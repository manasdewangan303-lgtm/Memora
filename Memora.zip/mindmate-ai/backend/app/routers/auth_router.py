from fastapi import APIRouter, HTTPException, status, Depends
from app.database import query_one
from app.auth import verify_password, create_access_token, get_current_user
from app.schemas import LoginRequest, DemoLoginRequest, TokenResponse

router = APIRouter(prefix="/auth", tags=["Authentication"])

@router.post("/login", response_model=TokenResponse)
def login(creds: LoginRequest):
    user = query_one("SELECT * FROM users WHERE username = ?", (creds.username,))
    if not user or not verify_password(creds.password, user["password_hash"]):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password"
        )
    
    patient_id = None
    caregiver_id = None
    if user["role"] == "patient":
        pat = query_one("SELECT id FROM patients WHERE user_id = ?", (user["id"],))
        if pat:
            patient_id = pat["id"]
    elif user["role"] == "caregiver":
        cg = query_one("SELECT id FROM caregivers WHERE user_id = ?", (user["id"],))
        if cg:
            caregiver_id = cg["id"]
            pat = query_one("SELECT id FROM patients WHERE caregiver_id = ?", (caregiver_id,))
            if pat:
                patient_id = pat["id"]

    token = create_access_token({"sub": user["id"], "role": user["role"], "username": user["username"]})
    return TokenResponse(
        access_token=token,
        user_id=user["id"],
        username=user["username"],
        role=user["role"],
        full_name=user["full_name"],
        patient_id=patient_id,
        caregiver_id=caregiver_id
    )

@router.post("/demo-login", response_model=TokenResponse)
def demo_login(req: DemoLoginRequest):
    """
    SIH Demo Shortcut: Allows instant 1-click login as Patient (Mrs. Sharma) or Caregiver (Mr. Sharma)
    """
    if req.role == "patient":
        user = query_one("SELECT * FROM users WHERE role = 'patient' LIMIT 1")
        pat = query_one("SELECT id FROM patients WHERE user_id = ?", (user["id"],))
        patient_id = pat["id"] if pat else "patient_demo_1"
        caregiver_id = None
    elif req.role == "caregiver":
        user = query_one("SELECT * FROM users WHERE role = 'caregiver' LIMIT 1")
        cg = query_one("SELECT id FROM caregivers WHERE user_id = ?", (user["id"],))
        caregiver_id = cg["id"] if cg else "cg_demo_1"
        pat = query_one("SELECT id FROM patients WHERE caregiver_id = ?", (caregiver_id,))
        patient_id = pat["id"] if pat else "patient_demo_1"
    else:
        raise HTTPException(status_code=400, detail="Invalid role for demo login")

    token = create_access_token({"sub": user["id"], "role": user["role"], "username": user["username"]})
    return TokenResponse(
        access_token=token,
        user_id=user["id"],
        username=user["username"],
        role=user["role"],
        full_name=user["full_name"],
        patient_id=patient_id,
        caregiver_id=caregiver_id
    )

@router.get("/me")
def get_me(current_user: dict = Depends(get_current_user)):
    if not current_user:
        return {"authenticated": False, "role": "anonymous"}
    return {
        "authenticated": True,
        "user_id": current_user["id"],
        "username": current_user["username"],
        "role": current_user["role"],
        "full_name": current_user["full_name"]
    }
