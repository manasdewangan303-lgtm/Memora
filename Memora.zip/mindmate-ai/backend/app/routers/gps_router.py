import math
import uuid
from datetime import datetime, timezone
from fastapi import APIRouter, HTTPException
from app.database import query_all, query_one, execute_write
from app.schemas import GPSPingCreate, GPSHomeUpdate

router = APIRouter(prefix="/gps", tags=["GPS & Home Assistance"])

def calculate_haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """
    Returns distance between two coordinates in kilometers.
    """
    R = 6371.0 # Earth radius in km
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = math.sin(dlat / 2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon / 2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R * c

@router.post("/ping")
def record_gps_ping(data: GPSPingCreate):
    patient = query_one("SELECT * FROM patients WHERE id = ?", (data.patient_id,))
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    new_id = str(uuid.uuid4())
    now_str = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")

    execute_write("""
        INSERT INTO gps_locations (id, patient_id, latitude, longitude, accuracy_m, recorded_at, sync_status)
        VALUES (?, ?, ?, ?, ?, ?, 'synced')
    """, (new_id, data.patient_id, data.latitude, data.longitude, data.accuracy_m or 10.0, now_str))

    # Calculate distance to home if home coords exist
    dist_km = None
    dist_text = "Home location not set"
    if patient["home_latitude"] and patient["home_longitude"]:
        dist_km = calculate_haversine_distance(
            data.latitude, data.longitude,
            patient["home_latitude"], patient["home_longitude"]
        )
        if dist_km < 0.1:
            dist_text = f"At Home ({int(dist_km * 1000)} meters)"
        elif dist_km < 1.0:
            dist_text = f"{int(dist_km * 1000)} meters from Home"
        else:
            dist_text = f"{dist_km:.2f} km from Home"

    return {
        "status": "success",
        "ping_id": new_id,
        "recorded_at": now_str,
        "distance_km": round(dist_km, 3) if dist_km is not None else None,
        "distance_text": dist_text,
        "home_address": patient.get("home_address")
    }

@router.post("/set-home")
def set_home_location(data: GPSHomeUpdate):
    patient = query_one("SELECT * FROM patients WHERE id = ?", (data.patient_id,))
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    execute_write("""
        UPDATE patients
        SET home_latitude = ?, home_longitude = ?, home_address = ?
        WHERE id = ?
    """, (data.home_latitude, data.home_longitude, data.home_address or "Saved Home", data.patient_id))

    return {
        "status": "success",
        "patient_id": data.patient_id,
        "home_latitude": data.home_latitude,
        "home_longitude": data.home_longitude,
        "home_address": data.home_address
    }

@router.get("/{patient_id}/latest")
def get_latest_gps(patient_id: str):
    patient = query_one("SELECT * FROM patients WHERE id = ?", (patient_id,))
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    latest_loc = query_one("""
        SELECT * FROM gps_locations
        WHERE patient_id = ?
        ORDER BY recorded_at DESC
        LIMIT 1
    """, (patient_id,))

    dist_km = None
    dist_text = "Unknown"
    if latest_loc and patient["home_latitude"] and patient["home_longitude"]:
        dist_km = calculate_haversine_distance(
            latest_loc["latitude"], latest_loc["longitude"],
            patient["home_latitude"], patient["home_longitude"]
        )
        dist_text = f"{int(dist_km * 1000)}m" if dist_km < 1.0 else f"{dist_km:.2f}km"

    return {
        "patient_id": patient_id,
        "home_latitude": patient.get("home_latitude"),
        "home_longitude": patient.get("home_longitude"),
        "home_address": patient.get("home_address"),
        "last_known_location": latest_loc,
        "distance_to_home_km": round(dist_km, 3) if dist_km is not None else None,
        "distance_text": dist_text
    }
