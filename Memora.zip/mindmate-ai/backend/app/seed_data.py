import uuid
from datetime import datetime, timedelta, timezone
from app.database import get_connection, query_one, execute_write
from app.auth import hash_password
from app.config import (
    DEFAULT_PATIENT_NAME,
    DEFAULT_PATIENT_AGE,
    DEFAULT_CAREGIVER_NAME,
    DEFAULT_HOME_LAT,
    DEFAULT_HOME_LNG,
    DEFAULT_HOME_ADDRESS
)

def seed_demo_data():
    conn = get_connection()
    cursor = conn.cursor()
    
    # Check if already seeded
    existing_patient = query_one("SELECT id FROM patients WHERE full_name = ?", (DEFAULT_PATIENT_NAME,))
    if existing_patient:
        conn.close()
        return

    now = datetime.now(timezone.utc)

    # 1. Users
    user_caregiver_id = "user_caregiver_demo"
    user_patient_id = "user_patient_demo"
    cursor.execute("""
        INSERT OR IGNORE INTO users (id, username, role, full_name, password_hash)
        VALUES (?, ?, ?, ?, ?)
    """, (user_caregiver_id, "caregiver_sharma", "caregiver", DEFAULT_CAREGIVER_NAME, hash_password("demo123")))

    cursor.execute("""
        INSERT OR IGNORE INTO users (id, username, role, full_name, password_hash)
        VALUES (?, ?, ?, ?, ?)
    """, (user_patient_id, "patient_sharma", "patient", DEFAULT_PATIENT_NAME, hash_password("demo123")))

    # 2. Caregiver
    caregiver_id = "cg_demo_1"
    cursor.execute("""
        INSERT OR IGNORE INTO caregivers (id, user_id, full_name, phone, relationship)
        VALUES (?, ?, ?, ?, ?)
    """, (caregiver_id, user_caregiver_id, DEFAULT_CAREGIVER_NAME, "+91 94350 98765", "Spouse / Primary Caregiver"))

    # 3. Patient
    patient_id = "patient_demo_1"
    cursor.execute("""
        INSERT OR IGNORE INTO patients (
            id, user_id, caregiver_id, full_name, age, emergency_contact,
            home_latitude, home_longitude, home_address, current_level
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        patient_id, user_patient_id, caregiver_id, DEFAULT_PATIENT_NAME,
        DEFAULT_PATIENT_AGE, "+91 98640 12345 (Son Rahul)",
        DEFAULT_HOME_LAT, DEFAULT_HOME_LNG, DEFAULT_HOME_ADDRESS, 2
    ))

    # 4. Past 7 Game Sessions (Realistic Cognitive Trends)
    sessions_data = [
        ("memory_match", 1, 80, 80.0, 5200, 1, 3, "Good recall on Level 1", now - timedelta(days=6)),
        ("sequence_recall", 1, 70, 70.0, 6800, 1, 3, "Gentle sequence completion", now - timedelta(days=5)),
        ("object_recognition", 1, 90, 90.0, 4100, 0, 3, "High familiarity with everyday items", now - timedelta(days=4)),
        ("memory_match", 2, 85, 85.0, 5800, 1, 4, "Strong performance on 4 objects", now - timedelta(days=3)),
        ("sequence_recall", 2, 65, 65.0, 7400, 2, 4, "Order recall maintained", now - timedelta(days=2)),
        ("object_recognition", 2, 92, 92.0, 3900, 0, 4, "Excellent prompt recognition", now - timedelta(days=1)),
        ("memory_match", 2, 88, 88.0, 5100, 1, 4, "Consistent engagement and focus", now - timedelta(hours=3)),
    ]

    for game_type, diff, score, acc, rt, mistakes, items, feedback, dt in sessions_data:
        cursor.execute("""
            INSERT INTO game_sessions (
                id, patient_id, game_type, difficulty_level, score, accuracy,
                response_time_ms, mistakes, items_count, feedback_text, sync_status, created_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'synced', ?)
        """, (str(uuid.uuid4()), patient_id, game_type, diff, score, acc, rt, mistakes, items, feedback, dt.strftime("%Y-%m-%d %H:%M:%S")))

    # 5. Reminders
    reminders = [
        ("Take Morning BP Tablet (Amlodipine 5mg)", "medicine", "08:00 AM", 1, "Daily", "Take with warm water after light breakfast"),
        ("Drink a glass of warm water", "hydration", "10:00 AM", 1, "Daily", "Keep hydrated throughout morning"),
        ("Post-Lunch Multivitamin & Calcium", "medicine", "02:00 PM", 0, "Daily", "Next reminder scheduled for 2:00 PM"),
        ("Afternoon Hydration - Lemon Water", "hydration", "03:00 PM", 0, "Daily", "Next reminder scheduled for 3:00 PM"),
        ("Gentle Garden Walk & Fresh Air", "activity", "05:00 PM", 0, "Daily", "15 minutes pleasant walk in veranda or compound"),
        ("Dr. Barua Memory Consultation", "appointment", "Friday 10:00 AM", 0, "Weekly", "Routine quarterly checkup at Guwahati Clinic"),
    ]

    for title, cat, sched, completed, freq, notes in reminders:
        cursor.execute("""
            INSERT INTO reminders (id, patient_id, title, category, scheduled_time, is_completed, frequency, notes, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (str(uuid.uuid4()), patient_id, title, cat, sched, completed, freq, notes, now.strftime("%Y-%m-%d %H:%M:%S")))

    # 6. Personal Memories
    memories = [
        (
            "Rahul", "Son",
            "Your elder son Rahul. He is an engineer living in Guwahati who visits every Sunday with your favorite sweets.",
            "avatar_son.png", "Your elder son"
        ),
        (
            "Priya", "Daughter",
            "Your daughter Priya. She lives in Pune and calls every evening at 7:00 PM to talk with you.",
            "avatar_daughter.png", "Your daughter"
        ),
        (
            "Shillong Cottage", "Important Place",
            "The family hillside summer house in Shillong where our family planted hydrangeas and spent summer holidays.",
            "avatar_place.png", "Family summer cottage"
        ),
        (
            "Morning Chai Cup", "Familiar Object",
            "Your favorite brass-rimmed clay teacup Rahul brought from Majuli. You drink morning ginger tea in this cup.",
            "avatar_cup.png", "Your morning tea cup"
        )
    ]

    for name, rel, desc, photo, hint in memories:
        cursor.execute("""
            INSERT INTO memories (id, patient_id, person_name, relationship, description, photo_url, hint, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (str(uuid.uuid4()), patient_id, name, rel, desc, photo, hint, now.strftime("%Y-%m-%d %H:%M:%S")))

    # 7. GPS Initial Location
    cursor.execute("""
        INSERT INTO gps_locations (id, patient_id, latitude, longitude, accuracy_m, recorded_at, sync_status)
        VALUES (?, ?, ?, ?, 8.5, ?, 'synced')
    """, (str(uuid.uuid4()), patient_id, DEFAULT_HOME_LAT + 0.0003, DEFAULT_HOME_LNG + 0.0002, (now - timedelta(minutes=15)).strftime("%Y-%m-%d %H:%M:%S")))

    # 8. Caregiver Alerts
    alerts = [
        ("Missed Reminder Notice", "Please review: 2:00 PM post-lunch reminder is approaching and pending confirmation.", "warning", 0),
        ("Routine Session Completed", "Patient completed yesterday's cognitive session with 88% accuracy.", "info", 1),
    ]

    for atype, msg, sev, rd in alerts:
        cursor.execute("""
            INSERT INTO caregiver_alerts (id, patient_id, alert_type, message, severity, is_read, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (str(uuid.uuid4()), patient_id, atype, msg, sev, rd, (now - timedelta(hours=2)).strftime("%Y-%m-%d %H:%M:%S")))

    conn.commit()
    conn.close()
