from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user_id: str
    username: str
    role: str
    full_name: str
    patient_id: Optional[str] = None
    caregiver_id: Optional[str] = None

class LoginRequest(BaseModel):
    username: str
    password: str

class DemoLoginRequest(BaseModel):
    role: str  # "patient" or "caregiver"

class UserCreate(BaseModel):
    username: str
    password: str
    full_name: str
    role: str

class PatientResponse(BaseModel):
    id: str
    user_id: str
    caregiver_id: Optional[str] = None
    full_name: str
    age: int
    emergency_contact: Optional[str] = None
    home_latitude: Optional[float] = None
    home_longitude: Optional[float] = None
    home_address: Optional[str] = None
    current_level: int = 1
    created_at: Optional[str] = None

class GameSessionCreate(BaseModel):
    patient_id: str
    game_type: str  # "memory_match", "sequence_recall", "object_recognition"
    difficulty_level: int
    score: int
    accuracy: float
    response_time_ms: int
    mistakes: int
    items_count: int
    feedback_text: Optional[str] = None
    client_id: Optional[str] = None

class AdaptiveEvaluationResponse(BaseModel):
    patient_id: str
    game_type: str
    previous_level: int
    next_level: int
    accuracy: float
    response_time_ms: int
    mistakes: int
    explanation: str
    trend_summary: str
    session_id: str

class ReminderCreate(BaseModel):
    patient_id: str
    title: str
    category: str  # 'medicine', 'hydration', 'activity', 'appointment'
    scheduled_time: str
    frequency: str = "Daily"
    notes: Optional[str] = None

class ReminderUpdate(BaseModel):
    title: Optional[str] = None
    category: Optional[str] = None
    scheduled_time: Optional[str] = None
    is_completed: Optional[int] = None
    frequency: Optional[str] = None
    notes: Optional[str] = None

class MemoryCreate(BaseModel):
    patient_id: str
    person_name: str
    relationship: str
    description: str
    photo_url: Optional[str] = None
    hint: Optional[str] = None

class GPSPingCreate(BaseModel):
    patient_id: str
    latitude: float
    longitude: float
    accuracy_m: Optional[float] = 10.0

class GPSHomeUpdate(BaseModel):
    patient_id: str
    home_latitude: float
    home_longitude: float
    home_address: Optional[str] = None

class SyncItem(BaseModel):
    client_uuid: str
    entity_type: str  # "game_session", "gps_ping", "reminder_status"
    payload: Dict[str, Any]

class SyncBatchRequest(BaseModel):
    items: List[SyncItem]

class SyncBatchResponse(BaseModel):
    synced_count: int
    status: str
    synced_ids: List[str]

class CaregiverDashboardResponse(BaseModel):
    patient: Dict[str, Any]
    today_sessions_count: int
    overall_accuracy: float
    last_active_time: Optional[str]
    category_breakdown: Dict[str, float]
    recent_trend: List[Dict[str, Any]]
    active_reminders: List[Dict[str, Any]]
    alerts: List[Dict[str, Any]]
    adaptive_status: Dict[str, Any]
