/**
 * GAME 3: OBJECT RECOGNITION
 * Section 10: Culturally familiar everyday object recognition with large buttons,
 * voice recognition, auditory prompts, and adaptive difficulty.
 */

const ObjectRecognitionGame = {
  objectsList: [
    {
      id: 'cup',
      name_en: 'Chai Tea Cup',
      name_hi: 'चाय का कप',
      name_as: 'চাহৰ কাপ',
      emoji: '☕',
      distractors_en: ['Book', 'Shoe'],
      distractors_hi: ['किताब', 'जूता'],
      distractors_as: ['কিতাপ', 'জোতা']
    },
    {
      id: 'diya',
      name_en: 'Clay Diya / Lamp',
      name_hi: 'मिट्टी का दीया',
      name_as: 'মাটিৰ চাকি',
      emoji: '🪔',
      distractors_en: ['Plate', 'Flower'],
      distractors_hi: ['थाली', 'फूल'],
      distractors_as: ['কাঁহী', 'ফুল']
    },
    {
      id: 'umbrella',
      name_en: 'Rain Umbrella',
      name_hi: 'छाता',
      name_as: 'ছাতি',
      emoji: '☂️',
      distractors_en: ['Clock', 'Bicycle'],
      distractors_hi: ['घड़ी', 'साइकिल'],
      distractors_as: ['ঘড়ী', 'চাইকেল']
    },
    {
      id: 'book',
      name_en: 'Reading Book',
      name_hi: 'किताब',
      name_as: 'কিতাপ',
      emoji: '📖',
      distractors_en: ['Mirror', 'Spoon'],
      distractors_hi: ['आईना', 'चम्मच'],
      distractors_as: ['আইনা', 'চামুচ']
    },
    {
      id: 'bell',
      name_en: 'Prayer Bell',
      name_hi: 'पूजा की घंटी',
      name_as: 'পূজাৰ ঘণ্টা',
      emoji: '🔔',
      distractors_en: ['Key', 'Cup'],
      distractors_hi: ['चाबी', 'कप'],
      distractors_as: ['চাবি', 'কাপ']
    }
  ],

  currentIndex: 0,
  currentObject: null,
  options: [],
  startTime: 0,
  currentLevel: 1,

  init(level = 1) {
    this.currentLevel = level;
    this.currentIndex = 0;
    const container = document.getElementById('patient-dynamic-content');
    if (!container) return;

    // Pick a random object
    this.currentObject = this.objectsList[Math.floor(Math.random() * this.objectsList.length)];
    this.renderQuestion(container);
  },

  renderQuestion(container) {
    this.startTime = Date.now();
    const correctName = this.getName(this.currentObject);
    const distNames = this.getDistractors(this.currentObject);
    this.options = [correctName, ...distNames].sort(() => 0.5 - Math.random());

    container.innerHTML = `
      <div class="game-view-container">
        <div class="game-top-nav">
          <button class="back-btn" onclick="PatientApp.showHome()">← Back</button>
          <span class="game-level-badge">Object Recognition</span>
        </div>

        <div class="instruction-banner">
          <div class="instruction-text">${t('what_is_this')}</div>
          <div class="instruction-sub">Look at the familiar object below and choose its name.</div>
        </div>

        <!-- Big Object Visual Display -->
        <div style="background: #FFFFFF; border: 4px solid #1E6091; border-radius: 28px; padding: 36px 20px; text-align: center; margin: 16px 0; box-shadow: var(--shadow-md);">
          <div style="font-size: 96px; line-height: 1;">${this.currentObject.emoji}</div>
        </div>

        <!-- Large 3 Option Buttons -->
        <div style="display: flex; flex-direction: column; gap: 14px;">
          ${this.options.map(opt => `
            <button class="elderly-btn" data-speak="${opt}" onclick="ObjectRecognitionGame.checkAnswer('${opt.replace(/'/g, "\\'")}')">
              <span class="btn-icon">👉</span>
              <div class="btn-text-wrap">
                <div class="btn-title" style="font-size: 24px;">${opt}</div>
              </div>
            </button>
          `).join('')}
        </div>

        <!-- Voice Recognition Bar -->
        <div class="voice-bar-assist" style="margin-top: 10px;">
          <button class="voice-mic-btn" onclick="ObjectRecognitionGame.startVoiceAnswer()" title="Speak answer">🎤</button>
          <div class="voice-status-text" id="voice-status-display">Tap mic to speak your answer (e.g., "${correctName.split(' ')[0]}")</div>
        </div>
      </div>
    `;

    VoiceService.speakKey('speak_what_object');
  },

  getName(obj) {
    if (currentLang === 'hi') return obj.name_hi;
    if (currentLang === 'as') return obj.name_as;
    return obj.name_en;
  },

  getDistractors(obj) {
    if (currentLang === 'hi') return obj.distractors_hi;
    if (currentLang === 'as') return obj.distractors_as;
    return obj.distractors_en;
  },

  startVoiceAnswer() {
    VoiceService.listen((spoken) => {
      const correct = this.getName(this.currentObject).toLowerCase();
      for (const opt of this.options) {
        if (spoken.includes(opt.toLowerCase()) || opt.toLowerCase().includes(spoken)) {
          this.checkAnswer(opt);
          return;
        }
      }
      VoiceService.speak("I heard your voice. You can also tap the large button!");
    });
  },

  checkAnswer(selected) {
    const responseTime = Date.now() - this.startTime;
    const correct = this.getName(this.currentObject);
    const isCorrect = (selected === correct);

    const accuracy = isCorrect ? 100 : 0;
    const mistakes = isCorrect ? 0 : 1;
    const score = isCorrect ? 100 : 30;

    let nextLevel = this.currentLevel;
    let explanation = isCorrect 
      ? "Difficulty maintained with outstanding visual recognition accuracy."
      : "Difficulty adjusted to support comfortable recall and confidence.";

    OfflineStore.saveGameSession({
      patient_id: 'patient_demo_1',
      game_type: 'object_recognition',
      difficulty_level: this.currentLevel,
      score: score,
      accuracy: accuracy,
      response_time_ms: responseTime,
      mistakes: mistakes,
      items_count: 1,
      feedback_text: explanation
    });

    this.renderResult(isCorrect, correct, responseTime, explanation);
  },

  renderResult(isCorrect, correctName, responseTime, explanation) {
    const container = document.getElementById('patient-dynamic-content');
    const celebrationEmoji = isCorrect ? "🎉" : "💡";
    const title = isCorrect ? t('well_done') : t('good_try');

    container.innerHTML = `
      <div class="game-view-container">
        <div class="result-card">
          <div class="result-celebration">${celebrationEmoji}</div>
          <div class="result-heading">${title}</div>
          <div style="font-size: 22px; font-weight: 800; color: #1E6091; margin-bottom: 8px;">
            It is a: ${correctName}
          </div>
          <div style="font-size: 16px; color: #4A5B65; margin-bottom: 14px;">
            Response Time: ${(responseTime / 1000).toFixed(1)}s
          </div>

          <div class="adaptive-next-level-box">
            <div class="adaptive-next-label">Explainable AI Adaptation</div>
            <div class="adaptive-reason">"${explanation}"</div>
          </div>

          <div style="display: flex; flex-direction: column; gap: 14px; margin-top: 20px;">
            <button class="elderly-btn primary-action" onclick="ObjectRecognitionGame.init()">
              <span class="btn-icon">🔄</span>
              <div class="btn-text-wrap"><div class="btn-title">NEXT OBJECT</div></div>
            </button>
            <button class="elderly-btn" onclick="PatientApp.showHome()">
              <span class="btn-icon">🏠</span>
              <div class="btn-text-wrap"><div class="btn-title">BACK TO HOME</div></div>
            </button>
          </div>
        </div>
      </div>
    `;

    if (isCorrect) {
      if (currentLang === 'hi') {
        VoiceService.speak(`सही जवाब! यह ${correctName} है। बहुत बढ़िया!`);
      } else if (currentLang === 'as') {
        VoiceService.speak(`সঠিক উত্তৰ! এইটো ${correctName}। বহুত ভাল!`);
      } else {
        VoiceService.speak(`Correct! It is a ${correctName}. Well done!`);
      }
    } else {
      if (currentLang === 'hi') {
        VoiceService.speak(`अच्छा प्रयास। यह ${correctName} है।`);
      } else if (currentLang === 'as') {
        VoiceService.speak(`ভাল চেষ্টা। এইটো ${correctName}।`);
      } else {
        VoiceService.speak(`That was a good try. It is a ${correctName}.`);
      }
    }
  }
};
