/**
 * GAME 2: SEQUENCE RECALL
 * Section 9: Sequence Recall with sequential display, order reproduction,
 * large buttons, mistakes calculation, voice assist, and adaptive AI.
 */

const SequenceRecallGame = {
  itemsPool: [
    { id: 'apple', label: 'Apple', emoji: '🍎', hindi: 'सेब', assam: 'আপেল' },
    { id: 'car', label: 'Car', emoji: '🚗', hindi: 'गाड़ी', assam: 'গাড়ী' },
    { id: 'elephant', label: 'Elephant', emoji: '🐘', hindi: 'हाथी', assam: 'হাতী' },
    { id: 'flower', label: 'Flower', emoji: '🌸', hindi: 'फूल', assam: 'ফুল' },
    { id: 'sun', label: 'Sun', emoji: '☀️', hindi: 'सूरज', assam: 'সূৰ্য' },
    { id: 'bell', label: 'Bell', emoji: '🔔', hindi: 'घंटी', assam: 'ঘণ্টী' }
  ],

  currentLevel: 1,
  sequence: [],
  userSequence: [],
  startTime: 0,

  init(level = 1) {
    this.currentLevel = level;
    this.userSequence = [];
    const container = document.getElementById('patient-dynamic-content');
    if (!container) return;

    // Sequence length: Level 1: 3, Level 2: 4, Level 3: 5, Level 4: 6
    const length = Math.min(6, Math.max(3, this.currentLevel + 2));
    const shuffled = [...this.itemsPool].sort(() => 0.5 - Math.random());
    this.sequence = shuffled.slice(0, length);

    this.renderDisplaySequence(container);
  },

  renderDisplaySequence(container) {
    container.innerHTML = `
      <div class="game-view-container">
        <div class="game-top-nav">
          <button class="back-btn" onclick="PatientApp.showHome()">← Back</button>
          <span class="game-level-badge">Level ${this.currentLevel} (${this.sequence.length} items)</span>
        </div>

        <div class="instruction-banner">
          <div class="instruction-text">${t('watch_sequence')}</div>
          <div class="instruction-sub">Remember the order from left to right.</div>
        </div>

        <!-- Sequence Card with arrows -->
        <div style="display: flex; align-items: center; justify-content: center; gap: 12px; flex-wrap: wrap; margin: 30px 0;">
          ${this.sequence.map((item, idx) => `
            <div class="object-card selected" style="min-width: 100px; padding: 20px 14px;">
              <div class="object-emoji">${item.emoji}</div>
              <div class="object-label">${this.getItemLabel(item)}</div>
              <div style="font-size: 13px; font-weight: 800; color: #1E6091; margin-top: 4px;">#${idx + 1}</div>
            </div>
            ${idx < this.sequence.length - 1 ? '<span style="font-size: 32px; font-weight: 900; color: #90A4AE;">→</span>' : ''}
          `).join('')}
        </div>

        <button class="elderly-btn primary-action" onclick="SequenceRecallGame.startRecall()">
          <span class="btn-icon">👁️</span>
          <div class="btn-text-wrap">
            <div class="btn-title">I'M READY TO REPEAT!</div>
            <div class="btn-subtext">Tap here to test your sequence memory</div>
          </div>
        </button>
      </div>
    `;

    VoiceService.speakKey('speak_watch_sequence');
  },

  getItemLabel(item) {
    if (currentLang === 'hi') return item.hindi;
    if (currentLang === 'as') return item.assam;
    return item.label;
  },

  startRecall() {
    this.startTime = Date.now();
    this.userSequence = [];
    const container = document.getElementById('patient-dynamic-content');
    if (!container) return;

    this.renderRecallStep(container);
  },

  renderRecallStep(container) {
    container.innerHTML = `
      <div class="game-view-container">
        <div class="game-top-nav">
          <button class="back-btn" onclick="PatientApp.showHome()">← Back</button>
          <span class="game-level-badge">Level ${this.currentLevel}</span>
        </div>

        <div class="instruction-banner">
          <div class="instruction-text">${t('repeat_sequence')}</div>
          <div class="instruction-sub">Selected ${this.userSequence.length} of ${this.sequence.length} items</div>
        </div>

        <!-- User Selection Progress Display -->
        <div style="min-height: 80px; background: #F8FAFC; border: 2px dashed #CBD5E1; border-radius: 16px; padding: 12px; display: flex; align-items: center; justify-content: center; gap: 12px; flex-wrap: wrap;">
          ${this.userSequence.length === 0 ? '<span style="color: #64748B; font-weight: 700;">Your tapped sequence will appear here</span>' : ''}
          ${this.userSequence.map((item, idx) => `
            <div class="object-card correct" style="min-height: auto; padding: 10px 16px;">
              <span style="font-size: 28px;">${item.emoji}</span>
              <span style="font-size: 15px; font-weight: 800; margin-left: 6px;">${this.getItemLabel(item)}</span>
            </div>
            ${idx < this.userSequence.length - 1 ? '<span style="font-size: 22px; font-weight: 900; color: #90A4AE;">→</span>' : ''}
          `).join('')}
        </div>

        <!-- Candidates to Tap -->
        <div class="objects-grid" style="margin-top: 10px;">
          ${this.itemsPool.map(item => `
            <div class="object-card" data-speak="${this.getItemLabel(item)}" onclick="SequenceRecallGame.tapCandidate('${item.id}')">
              <div class="object-emoji">${item.emoji}</div>
              <div class="object-label">${this.getItemLabel(item)}</div>
            </div>
          `).join('')}
        </div>

        <!-- Action buttons -->
        <div style="display: flex; gap: 12px; margin-top: 10px;">
          <button class="elderly-btn" style="flex: 1;" onclick="SequenceRecallGame.resetSelection()">
            <span class="btn-icon">↺</span>
            <div class="btn-text-wrap"><div class="btn-title">CLEAR</div></div>
          </button>
          <button class="elderly-btn primary-action" style="flex: 2;" onclick="SequenceRecallGame.submitSequence()">
            <span class="btn-icon">✓</span>
            <div class="btn-text-wrap"><div class="btn-title">DONE</div></div>
          </button>
        </div>
      </div>
    `;

    VoiceService.speakKey('speak_repeat_sequence');
  },

  tapCandidate(itemId) {
    if (this.userSequence.length >= this.sequence.length) return;
    const item = this.itemsPool.find(i => i.id === itemId);
    if (item) {
      this.userSequence.push(item);
      const container = document.getElementById('patient-dynamic-content');
      this.renderRecallStep(container);
    }
  },

  resetSelection() {
    this.userSequence = [];
    const container = document.getElementById('patient-dynamic-content');
    this.renderRecallStep(container);
  },

  submitSequence() {
    const responseTime = Date.now() - this.startTime;
    let correctCount = 0;
    let mistakes = 0;

    for (let i = 0; i < this.sequence.length; i++) {
      if (this.userSequence[i] && this.userSequence[i].id === this.sequence[i].id) {
        correctCount++;
      } else {
        mistakes++;
      }
    }

    const accuracy = Math.round((correctCount / this.sequence.length) * 100);
    const score = accuracy;

    // Adaptive evaluation
    let nextLevel = this.currentLevel;
    let adaptiveExplanation = "";

    if (accuracy >= 85) {
      nextLevel = Math.min(4, this.currentLevel + 1);
      adaptiveExplanation = "Difficulty increased because of strong sequence recall and prompt order execution.";
    } else if (accuracy >= 50) {
      nextLevel = this.currentLevel;
      adaptiveExplanation = "Difficulty maintained to build steady sequential recall confidence.";
    } else {
      nextLevel = Math.max(1, this.currentLevel - 1);
      adaptiveExplanation = "Difficulty adjusted to support comfortable recall and confidence.";
    }

    OfflineStore.saveGameSession({
      patient_id: 'patient_demo_1',
      game_type: 'sequence_recall',
      difficulty_level: this.currentLevel,
      score: score,
      accuracy: accuracy,
      response_time_ms: responseTime,
      mistakes: mistakes,
      items_count: this.sequence.length,
      feedback_text: adaptiveExplanation
    });

    this.currentLevel = nextLevel;
    this.renderResult(score, accuracy, responseTime, mistakes, nextLevel, adaptiveExplanation);
  },

  renderResult(score, accuracy, responseTime, mistakes, nextLevel, adaptiveExplanation) {
    const container = document.getElementById('patient-dynamic-content');
    const isSuccess = accuracy >= 70;
    const celebrationEmoji = isSuccess ? "🎉" : "⭐";
    const feedbackTitle = isSuccess ? t('well_done') : t('good_try');

    container.innerHTML = `
      <div class="game-view-container">
        <div class="result-card">
          <div class="result-celebration">${celebrationEmoji}</div>
          <div class="result-heading">${feedbackTitle}</div>
          <div class="result-accuracy">Sequence Accuracy: ${accuracy}%</div>
          <div style="font-size: 16px; color: #4A5B65; margin-bottom: 12px;">
            Response Time: ${(responseTime / 1000).toFixed(1)}s &nbsp;|&nbsp; Sequence Mistakes: ${mistakes}
          </div>

          <div class="adaptive-next-level-box">
            <div class="adaptive-next-label">Explainable AI Adaptation</div>
            <div class="adaptive-next-val">Next Session: Level ${nextLevel}</div>
            <div class="adaptive-reason">"${adaptiveExplanation}"</div>
          </div>

          <div style="display: flex; flex-direction: column; gap: 14px; margin-top: 20px;">
            <button class="elderly-btn primary-action" onclick="SequenceRecallGame.init(${nextLevel})">
              <span class="btn-icon">🔄</span>
              <div class="btn-text-wrap">
                <div class="btn-title">PLAY AGAIN</div>
                <div class="btn-subtext">Sequence difficulty: Level ${nextLevel}</div>
              </div>
            </button>
            <button class="elderly-btn" onclick="PatientApp.showHome()">
              <span class="btn-icon">🏠</span>
              <div class="btn-text-wrap"><div class="btn-title">BACK TO HOME</div></div>
            </button>
          </div>
        </div>
      </div>
    `;

    VoiceService.speakKey(isSuccess ? 'speak_sequence_success' : 'speak_sequence_try');
  }
};
