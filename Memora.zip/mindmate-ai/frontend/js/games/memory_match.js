/**
 * GAME 1: MEMORY MATCH
 * Section 8: Memory Match with Levels 1-4, 5-second observation timer,
 * candidate selection, multi-factor scoring, voice prompts, and adaptive AI integration.
 */

const MemoryMatchGame = {
  allObjects: [
    { id: 'apple', label: 'Apple', emoji: '🍎', hindi: 'सेब', assam: 'আপেল' },
    { id: 'key', label: 'Key', emoji: '🔑', hindi: 'चाबी', assam: 'চাবি' },
    { id: 'tea', label: 'Tea Cup', emoji: '☕', hindi: 'चाय का कप', assam: 'চাহৰ কাপ' },
    { id: 'book', label: 'Book', emoji: '📖', hindi: 'किताब', assam: 'কিতাপ' },
    { id: 'glasses', label: 'Glasses', emoji: '👓', hindi: 'चश्मा', assam: 'চশমা' },
    { id: 'bell', label: 'Temple Bell', emoji: '🔔', hindi: 'घंटी', assam: 'ঘণ্টী' },
    { id: 'flower', label: 'Marigold', emoji: '🌼', hindi: 'गेंदा फूल', assam: 'গাঁদা ফুল' },
    { id: 'umbrella', label: 'Umbrella', emoji: '☂️', hindi: 'छाता', assam: 'ছাতি' }
  ],

  currentLevel: 2, // Default Level 2 (4 items)
  targetItems: [],
  selectedItems: new Set(),
  startTime: 0,
  timerInterval: null,

  init(level = 2) {
    this.currentLevel = level;
    this.selectedItems.clear();
    const container = document.getElementById('patient-dynamic-content');
    if (!container) return;

    // Pick target count based on difficulty level
    // Level 1: 3, Level 2: 4, Level 3: 5, Level 4: 6
    const count = Math.min(6, Math.max(3, this.currentLevel + 2));
    const shuffled = [...this.allObjects].sort(() => 0.5 - Math.random());
    this.targetItems = shuffled.slice(0, count);

    this.renderStep1ShowObjects(container);
  },

  renderStep1ShowObjects(container) {
    const levelLabel = `Level ${this.currentLevel} (${this.targetItems.length} Objects)`;
    
    container.innerHTML = `
      <div class="game-view-container">
        <div class="game-top-nav">
          <button class="back-btn" onclick="PatientApp.showHome()">← Back</button>
          <span class="game-level-badge">${levelLabel}</span>
        </div>

        <div class="instruction-banner">
          <div class="instruction-text">${t('look_carefully')}</div>
          <div class="instruction-sub">Remember these objects. They will hide in 5 seconds!</div>
          <div class="timer-bar-wrap">
            <div id="memory-timer-fill" class="timer-bar-fill"></div>
          </div>
        </div>

        <div class="objects-grid">
          ${this.targetItems.map(item => `
            <div class="object-card selected" data-speak="${this.getItemLabel(item)}">
              <div class="object-emoji">${item.emoji}</div>
              <div class="object-label">${this.getItemLabel(item)}</div>
            </div>
          `).join('')}
        </div>
      </div>
    `;

    VoiceService.speakKey('speak_look_carefully');

    // Animate 5-second observation countdown
    let timeLeft = 5000;
    const step = 50;
    const timerFill = document.getElementById('memory-timer-fill');

    clearInterval(this.timerInterval);
    this.timerInterval = setInterval(() => {
      timeLeft -= step;
      if (timerFill) {
        const percent = Math.max(0, (timeLeft / 5000) * 100);
        timerFill.style.width = percent + '%';
      }

      if (timeLeft <= 0) {
        clearInterval(this.timerInterval);
        this.renderStep2Selection(container);
      }
    }, step);
  },

  renderStep2Selection(container) {
    this.startTime = Date.now();
    this.selectedItems.clear();

    // 6 Candidates including all target items + random distractors
    const distractors = this.allObjects.filter(item => !this.targetItems.some(t => t.id === item.id));
    const neededDistractors = Math.max(2, 6 - this.targetItems.length);
    const chosenDistractors = distractors.sort(() => 0.5 - Math.random()).slice(0, neededDistractors);
    const candidates = [...this.targetItems, ...chosenDistractors].sort(() => 0.5 - Math.random());

    const levelLabel = `Level ${this.currentLevel}`;

    container.innerHTML = `
      <div class="game-view-container">
        <div class="game-top-nav">
          <button class="back-btn" onclick="PatientApp.showHome()">← Back</button>
          <span class="game-level-badge">${levelLabel}</span>
        </div>

        <div class="instruction-banner">
          <div class="instruction-text">${t('which_did_you_see')}</div>
          <div class="instruction-sub">Tap the ${this.targetItems.length} objects you remember.</div>
        </div>

        <!-- Candidate Cards -->
        <div class="objects-grid" id="candidates-grid">
          ${candidates.map(item => `
            <div class="object-card" id="candidate-${item.id}" data-speak="${this.getItemLabel(item)}" onclick="MemoryMatchGame.toggleSelection('${item.id}')">
              <div class="object-emoji">${item.emoji}</div>
              <div class="object-label">${this.getItemLabel(item)}</div>
            </div>
          `).join('')}
        </div>

        <!-- Voice assistance input bar -->
        <div class="voice-bar-assist">
          <button class="voice-mic-btn" onclick="MemoryMatchGame.startVoiceSelection()" title="Speak answer">🎤</button>
          <div class="voice-status-text" id="voice-status-display">Tap cards or tap mic to speak your answer</div>
        </div>

        <button class="elderly-btn primary-action" style="margin-top: 10px;" onclick="MemoryMatchGame.submitAnswers()">
          <span class="btn-icon">✓</span>
          <div class="btn-text-wrap">
            <div class="btn-title">CHECK MY ANSWERS</div>
          </div>
        </button>
      </div>
    `;

    VoiceService.speakKey('speak_which_objects');
  },

  getItemLabel(item) {
    if (currentLang === 'hi') return item.hindi;
    if (currentLang === 'as') return item.assam;
    return item.label;
  },

  toggleSelection(itemId) {
    const card = document.getElementById(`candidate-${itemId}`);
    if (this.selectedItems.has(itemId)) {
      this.selectedItems.delete(itemId);
      if (card) card.classList.remove('selected');
    } else {
      this.selectedItems.add(itemId);
      if (card) card.classList.add('selected');
    }
  },

  startVoiceSelection() {
    VoiceService.listen((spokenText) => {
      this.allObjects.forEach(item => {
        if (spokenText.includes(item.label.toLowerCase()) || 
            spokenText.includes(item.hindi) || 
            spokenText.includes(item.id)) {
          this.toggleSelection(item.id);
        }
      });
    });
  },

  submitAnswers() {
    const responseTime = Date.now() - this.startTime;
    const targetIds = new Set(this.targetItems.map(t => t.id));

    let correctCount = 0;
    let mistakes = 0;

    this.selectedItems.forEach(id => {
      if (targetIds.has(id)) {
        correctCount++;
      } else {
        mistakes++;
      }
    });

    // Missed items also count towards mistakes
    const missedCount = targetIds.size - correctCount;
    mistakes += missedCount;

    const accuracy = Math.round((correctCount / targetIds.size) * 100);
    const score = Math.max(0, accuracy);

    // Call Adaptive Engine logic
    let nextLevel = this.currentLevel;
    let adaptiveExplanation = "";

    if (accuracy >= 85) {
      nextLevel = Math.min(4, this.currentLevel + 1);
      adaptiveExplanation = "Difficulty increased because of consistently strong recent performance.";
    } else if (accuracy >= 50) {
      nextLevel = this.currentLevel;
      adaptiveExplanation = "Difficulty maintained to build steady familiarity and confidence.";
    } else {
      nextLevel = Math.max(1, this.currentLevel - 1);
      adaptiveExplanation = "Difficulty adjusted to support comfortable recall and confidence.";
    }

    // Save session to local/backend store
    const sessionRecord = {
      patient_id: 'patient_demo_1',
      game_type: 'memory_match',
      difficulty_level: this.currentLevel,
      score: score,
      accuracy: accuracy,
      response_time_ms: responseTime,
      mistakes: mistakes,
      items_count: targetIds.size,
      feedback_text: adaptiveExplanation
    };

    OfflineStore.saveGameSession(sessionRecord);

    // Update patient's current level in local state
    this.currentLevel = nextLevel;

    // Render result celebration
    this.renderResult(score, accuracy, responseTime, mistakes, nextLevel, adaptiveExplanation);
  },

  renderResult(score, accuracy, responseTime, mistakes, nextLevel, adaptiveExplanation) {
    const container = document.getElementById('patient-dynamic-content');
    const isSuccess = accuracy >= 70;
    const celebrationEmoji = isSuccess ? "🎉" : "🌸";
    const feedbackTitle = isSuccess ? t('well_done') : t('good_try');
    const speechMsg = isSuccess ? "Well done! That was excellent recall." : "Good try! Keep going, you are doing wonderful.";

    container.innerHTML = `
      <div class="game-view-container">
        <div class="result-card">
          <div class="result-celebration">${celebrationEmoji}</div>
          <div class="result-heading">${feedbackTitle}</div>
          <div class="result-accuracy">Accuracy: ${accuracy}%</div>
          <div style="font-size: 16px; color: #4A5B65; margin-bottom: 12px;">
            Response Time: ${(responseTime / 1000).toFixed(1)}s &nbsp;|&nbsp; Mistakes: ${mistakes}
          </div>

          <!-- Explainable Adaptive AI Feedback Box -->
          <div class="adaptive-next-level-box">
            <div class="adaptive-next-label">Explainable AI Adaptation</div>
            <div class="adaptive-next-val">Next Session: Level ${nextLevel}</div>
            <div class="adaptive-reason">"${adaptiveExplanation}"</div>
          </div>

          <div style="display: flex; flex-direction: column; gap: 14px; margin-top: 20px;">
            <button class="elderly-btn primary-action" onclick="MemoryMatchGame.init(${nextLevel})">
              <span class="btn-icon">🔄</span>
              <div class="btn-text-wrap">
                <div class="btn-title">PLAY AGAIN</div>
                <div class="btn-subtext">Start next session at Level ${nextLevel}</div>
              </div>
            </button>

            <button class="elderly-btn" onclick="PatientApp.showHome()">
              <span class="btn-icon">🏠</span>
              <div class="btn-text-wrap">
                <div class="btn-title">BACK TO HOME</div>
              </div>
            </button>
          </div>
        </div>
      </div>
    `;

    VoiceService.speakKey(isSuccess ? 'speak_well_done' : 'speak_good_try');

    // Update today's cognitive session status in Home
    const statusEl = document.getElementById('home-session-status');
    if (statusEl) {
      statusEl.textContent = `Completed (Level ${nextLevel}) ✓`;
      statusEl.parentElement.classList.add('completed');
    }
  }
};
