/**
 * MEMORA - Offline-First Local Store & Synchronization Engine
 * Simulates local SQLite / IndexedDB client database with transactional sync queue.
 */

const OfflineStore = {
  isOnline: true,
  LOCAL_SESSIONS_KEY: 'memora_local_sessions',
  LOCAL_GPS_KEY: 'memora_local_gps',
  LOCAL_REMINDERS_KEY: 'memora_local_reminders',
  LOCAL_PATIENT_KEY: 'memora_local_patient',

  init() {
    // Backward compatibility migration from legacy mindmate_* keys
    const legacyMap = [
      ['mindmate_local_sessions', this.LOCAL_SESSIONS_KEY],
      ['mindmate_local_gps', this.LOCAL_GPS_KEY],
      ['mindmate_local_reminders', this.LOCAL_REMINDERS_KEY],
      ['mindmate_local_patient', this.LOCAL_PATIENT_KEY]
    ];
    legacyMap.forEach(([oldKey, newKey]) => {
      try {
        if (typeof localStorage !== 'undefined') {
          const oldVal = localStorage.getItem(oldKey);
          if (oldVal && !localStorage.getItem(newKey)) {
            localStorage.setItem(newKey, oldVal);
          }
        }
      } catch (e) {}
    });

    if (!localStorage.getItem(this.LOCAL_SESSIONS_KEY)) {
      localStorage.setItem(this.LOCAL_SESSIONS_KEY, JSON.stringify([]));
    }
    if (!localStorage.getItem(this.LOCAL_GPS_KEY)) {
      localStorage.setItem(this.LOCAL_GPS_KEY, JSON.stringify([]));
    }
  },

  setNetworkStatus(online) {
    this.isOnline = online;
    const btn = document.getElementById('network-toggle-btn');
    const label = document.getElementById('network-status-label');
    const toast = document.getElementById('sync-toast');

    if (this.isOnline) {
      if (btn) {
        btn.className = 'network-toggle-btn online';
        label.textContent = '🟢 Online';
      }
      // If returning to online, trigger synchronization
      this.synchronizePendingRecords();
    } else {
      if (btn) {
        btn.className = 'network-toggle-btn offline';
        label.textContent = '🟠 Offline Mode';
      }
      if (toast) {
        toast.className = 'sync-toast syncing';
        toast.textContent = 'Operating in Offline Mode. All progress will be saved locally.';
        setTimeout(() => { toast.style.display = 'none'; }, 3500);
      }
    }
  },

  toggleNetwork() {
    this.setNetworkStatus(!this.isOnline);
  },

  saveGameSession(sessionData) {
    const clientUuid = 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6);
    const session = {
      ...sessionData,
      client_uuid: clientUuid,
      sync_status: this.isOnline ? 'synced' : 'pending',
      timestamp: new Date().toISOString().replace('T', ' ').substr(0, 19)
    };

    // Always store in local store
    const localSessions = JSON.parse(localStorage.getItem(this.LOCAL_SESSIONS_KEY) || '[]');
    localSessions.unshift(session);
    localStorage.setItem(this.LOCAL_SESSIONS_KEY, JSON.stringify(localSessions));

    if (this.isOnline) {
      // Send directly to backend
      fetch('/api/game-results', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(sessionData)
      })
      .then(res => res.json())
      .then(data => {
        console.log("Game result submitted online:", data);
        if (window.CaregiverApp) window.CaregiverApp.refreshData();
      })
      .catch(err => {
        console.warn("Online post failed, marking as pending:", err);
        session.sync_status = 'pending';
        localStorage.setItem(this.LOCAL_SESSIONS_KEY, JSON.stringify(localSessions));
      });
    } else {
      console.log("Offline mode: Session stored locally with status pending:", session);
    }

    return session;
  },

  saveGPSPing(lat, lng) {
    const pingUuid = 'gps_' + Date.now();
    const ping = {
      client_uuid: pingUuid,
      patient_id: 'patient_demo_1',
      latitude: lat,
      longitude: lng,
      sync_status: this.isOnline ? 'synced' : 'pending',
      timestamp: new Date().toISOString().replace('T', ' ').substr(0, 19)
    };

    const localGPS = JSON.parse(localStorage.getItem(this.LOCAL_GPS_KEY) || '[]');
    localGPS.unshift(ping);
    localStorage.setItem(this.LOCAL_GPS_KEY, JSON.stringify(localGPS));

    if (this.isOnline) {
      fetch('/api/gps/ping', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ patient_id: 'patient_demo_1', latitude: lat, longitude: lng })
      }).catch(e => console.warn("GPS ping error:", e));
    }
  },

  getPendingCount() {
    const sessions = JSON.parse(localStorage.getItem(this.LOCAL_SESSIONS_KEY) || '[]');
    const gps = JSON.parse(localStorage.getItem(this.LOCAL_GPS_KEY) || '[]');
    const pendingSessions = sessions.filter(s => s.sync_status === 'pending');
    const pendingGPS = gps.filter(g => g.sync_status === 'pending');
    return pendingSessions.length + pendingGPS.length;
  },

  async synchronizePendingRecords() {
    const sessions = JSON.parse(localStorage.getItem(this.LOCAL_SESSIONS_KEY) || '[]');
    const gps = JSON.parse(localStorage.getItem(this.LOCAL_GPS_KEY) || '[]');

    const pendingSessions = sessions.filter(s => s.sync_status === 'pending');
    const pendingGPS = gps.filter(g => g.sync_status === 'pending');

    if (pendingSessions.length === 0 && pendingGPS.length === 0) {
      return;
    }

    const toast = document.getElementById('sync-toast');
    if (toast) {
      toast.className = 'sync-toast syncing';
      toast.textContent = `Synchronizing ${pendingSessions.length + pendingGPS.length} offline records...`;
      toast.style.display = 'block';
    }

    const itemsToSync = [];
    pendingSessions.forEach(s => {
      itemsToSync.push({
        client_uuid: s.client_uuid,
        entity_type: 'game_session',
        payload: s
      });
    });

    pendingGPS.forEach(g => {
      itemsToSync.push({
        client_uuid: g.client_uuid,
        entity_type: 'gps_ping',
        payload: g
      });
    });

    try {
      const response = await fetch('/api/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ items: itemsToSync })
      });

      if (response.ok) {
        const result = await response.json();
        const syncedIds = new Set(result.synced_ids);

        // Mark local items as synced
        sessions.forEach(s => {
          if (syncedIds.has(s.client_uuid)) s.sync_status = 'synced';
        });
        gps.forEach(g => {
          if (syncedIds.has(g.client_uuid)) g.sync_status = 'synced';
        });

        localStorage.setItem(this.LOCAL_SESSIONS_KEY, JSON.stringify(sessions));
        localStorage.setItem(this.LOCAL_GPS_KEY, JSON.stringify(gps));

        if (toast) {
          toast.className = 'sync-toast success';
          toast.textContent = `Sync complete ✓ (${result.synced_count} records synchronized)`;
          setTimeout(() => { toast.style.display = 'none'; }, 3000);
        }

        // Live refresh caregiver dashboard if open
        if (window.CaregiverApp) {
          window.CaregiverApp.refreshData();
        }
      }
    } catch (err) {
      console.warn("Sync failed, will retry later:", err);
      if (toast) {
        toast.className = 'sync-toast syncing';
        toast.textContent = 'Synchronization pending (waiting for connection)...';
      }
    }
  }
};

OfflineStore.init();
