/**
 * MEMORA - Caregiver Dashboard Logic
 * Section 20-23: Clinical metrics, explainable AI explanations, Chart.js trends,
 * reminder & memory management, and GPS configuration.
 */

const CaregiverApp = {
  patientId: 'patient_demo_1',
  dashboardData: null,
  trendChart: null,

  async init() {
    await this.refreshData();
  },

  async refreshData() {
    try {
      const res = await fetch(`/api/dashboard/${this.patientId}`);
      if (res.ok) {
        this.dashboardData = await res.json();
        this.render();
      } else {
        // Use offline fallback mock if backend is momentarily unreachable
        this.renderFallback();
      }
    } catch (e) {
      console.warn("Caregiver dashboard fetch error, using local fallback:", e);
      this.renderFallback();
    }
  },

  render() {
    const data = this.dashboardData;
    if (!data) return;

    // 1. Patient Hero Stats
    const patientNameEl = document.getElementById('cg-patient-name');
    if (patientNameEl) patientNameEl.textContent = data.patient.full_name;

    const patientAgeEl = document.getElementById('cg-patient-age');
    if (patientAgeEl) patientAgeEl.textContent = `Age: ${data.patient.age}`;

    const lastActiveEl = document.getElementById('cg-last-active');
    if (lastActiveEl) lastActiveEl.textContent = data.last_active_time || 'Recent';

    const currentLevelEl = document.getElementById('cg-current-level');
    if (currentLevelEl) currentLevelEl.textContent = `Level ${data.patient.current_level}`;

    const sessionsTodayEl = document.getElementById('cg-sessions-today');
    if (sessionsTodayEl) sessionsTodayEl.textContent = data.today_sessions_count;

    // 2. Explainable AI Status Card
    const aiExplanationEl = document.getElementById('cg-ai-explanation');
    if (aiExplanationEl) {
      aiExplanationEl.textContent = data.adaptive_status.explanation;
    }

    // 3. Cognitive Domains Overview
    const overview = data.cognitive_overview;
    this.updateDomainUI('mem', overview.memory);
    this.updateDomainUI('att', overview.attention);
    this.updateDomainUI('seq', overview.sequence);
    this.updateDomainUI('rec', overview.recognition);

    // 4. Alerts List
    this.renderAlerts(data.alerts);

    // 5. Reminders Tab Content
    this.renderReminders(data.active_reminders);

    // 6. Render Trend Chart
    this.renderChart(data.recent_trend);

    // 7. Load Memories
    this.loadMemories();
  },

  updateDomainUI(prefix, val) {
    const scoreEl = document.getElementById(`cg-score-${prefix}`);
    const barEl = document.getElementById(`cg-bar-${prefix}`);
    if (scoreEl) scoreEl.textContent = `${Math.round(val)}%`;
    if (barEl) barEl.style.width = `${Math.min(100, Math.max(10, val))}%`;
  },

  renderAlerts(alerts) {
    const listEl = document.getElementById('cg-alerts-list');
    if (!listEl) return;

    if (!alerts || alerts.length === 0) {
      listEl.innerHTML = '<div style="color: #64748B; font-size: 14px;">No active alerts. Patient routine is stable.</div>';
      return;
    }

    listEl.innerHTML = alerts.map(a => `
      <div class="alert-item ${a.severity || 'warning'}">
        <div class="alert-title">⚠ ${a.alert_type}</div>
        <div class="alert-msg">${a.message}</div>
        <div class="alert-time">${a.created_at || 'Today'}</div>
      </div>
    `).join('');
  },

  renderReminders(reminders) {
    const listEl = document.getElementById('cg-reminders-table');
    if (!listEl) return;

    if (!reminders || reminders.length === 0) {
      listEl.innerHTML = '<tr><td colspan="4" style="text-align: center; color: #64748B;">No reminders scheduled</td></tr>';
      return;
    }

    listEl.innerHTML = reminders.map(r => `
      <tr style="border-bottom: 1px solid #E2E8F0;">
        <td style="padding: 12px 14px; font-weight: 700;">${r.title}</td>
        <td style="padding: 12px 14px;"><span class="hero-pill" style="background: #E2E8F0; color: #334155;">${r.category.toUpperCase()}</span></td>
        <td style="padding: 12px 14px; font-weight: 600;">${r.scheduled_time}</td>
        <td style="padding: 12px 14px;">
          ${r.is_completed ? '<span style="color: #10B981; font-weight: 800;">Completed ✓</span>' : '<span style="color: #F59E0B; font-weight: 800;">Pending</span>'}
        </td>
      </tr>
    `).join('');
  },

  async loadMemories() {
    const grid = document.getElementById('cg-memories-grid');
    if (!grid) return;
    try {
      const res = await fetch(`/api/memories/${this.patientId}`);
      if (res.ok) {
        const memories = await res.json();
        grid.innerHTML = memories.map(m => `
          <div class="memory-card">
            <div class="memory-thumb">📸</div>
            <div class="memory-details">
              <h4>${m.person_name}</h4>
              <div class="memory-rel">${m.relationship}</div>
              <div class="memory-desc">${m.description}</div>
            </div>
          </div>
        `).join('');
      }
    } catch(e) {}
  },

  renderChart(trendData) {
    const canvas = document.getElementById('cg-trend-chart');
    if (!canvas) return;

    const labels = (trendData || []).map((t, idx) => `Session #${idx + 1}`);
    const accuracyData = (trendData || []).map(t => t.accuracy);
    const responseTimeData = (trendData || []).map(t => (t.response_time_ms / 1000).toFixed(1));

    if (this.trendChart) {
      this.trendChart.destroy();
    }

    if (typeof Chart === 'undefined') return;

    this.trendChart = new Chart(canvas, {
      type: 'line',
      data: {
        labels: labels.length ? labels : ['Day 1', 'Day 2', 'Day 3', 'Day 4', 'Day 5', 'Day 6', 'Day 7'],
        datasets: [
          {
            label: 'Accuracy (%)',
            data: accuracyData.length ? accuracyData : [80, 70, 90, 85, 65, 92, 88],
            borderColor: '#10B981',
            backgroundColor: 'rgba(16, 185, 129, 0.1)',
            tension: 0.3,
            fill: true,
            yAxisID: 'y'
          },
          {
            label: 'Response Time (s)',
            data: responseTimeData.length ? responseTimeData : [5.2, 6.8, 4.1, 5.8, 7.4, 3.9, 5.1],
            borderColor: '#3B82F6',
            backgroundColor: 'transparent',
            borderDash: [5, 5],
            tension: 0.3,
            yAxisID: 'y1'
          }
        ]
      },
      options: {
        responsive: true,
        interaction: { mode: 'index', intersect: false },
        scales: {
          y: {
            type: 'linear',
            display: true,
            position: 'left',
            min: 40,
            max: 100,
            title: { display: true, text: 'Accuracy %' }
          },
          y1: {
            type: 'linear',
            display: true,
            position: 'right',
            grid: { drawOnChartArea: false },
            title: { display: true, text: 'Seconds' }
          }
        }
      }
    });
  },

  async addReminder(e) {
    if (e) e.preventDefault();
    const title = document.getElementById('rem-title').value;
    const cat = document.getElementById('rem-category').value;
    const time = document.getElementById('rem-time').value;

    if (!title || !time) return;

    await fetch('/api/reminders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        patient_id: this.patientId,
        title: title,
        category: cat,
        scheduled_time: time,
        frequency: 'Daily'
      })
    });

    document.getElementById('rem-title').value = '';
    document.getElementById('rem-time').value = '';
    alert('Reminder added successfully!');
    this.refreshData();
  },

  async addMemory(e) {
    if (e) e.preventDefault();
    const name = document.getElementById('mem-name').value;
    const rel = document.getElementById('mem-rel').value;
    const desc = document.getElementById('mem-desc').value;

    if (!name || !rel) return;

    await fetch('/api/memories', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        patient_id: this.patientId,
        person_name: name,
        relationship: rel,
        description: desc
      })
    });

    document.getElementById('mem-name').value = '';
    document.getElementById('mem-rel').value = '';
    document.getElementById('mem-desc').value = '';
    alert('Family memory added successfully!');
    this.loadMemories();
  },

  async setHomeLocation(e) {
    if (e) e.preventDefault();
    const lat = parseFloat(document.getElementById('home-lat').value);
    const lng = parseFloat(document.getElementById('home-lng').value);
    const addr = document.getElementById('home-addr').value;

    await fetch('/api/gps/set-home', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        patient_id: this.patientId,
        home_latitude: lat,
        home_longitude: lng,
        home_address: addr
      })
    });

    GPSService.homeLocation = { lat, lng, address: addr };
    alert('Home GPS coordinates updated!');
  },

  switchTab(tabId) {
    document.querySelectorAll('.cg-tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.cg-tab-content').forEach(c => c.classList.remove('active'));

    const btn = document.getElementById(`tab-btn-${tabId}`);
    const content = document.getElementById(`tab-content-${tabId}`);
    if (btn) btn.classList.add('active');
    if (content) content.classList.add('active');
  },

  renderFallback() {
    this.updateDomainUI('mem', 82.0);
    this.updateDomainUI('att', 74.0);
    this.updateDomainUI('seq', 68.0);
    this.updateDomainUI('rec', 88.0);
    this.renderChart([]);
  }
};
