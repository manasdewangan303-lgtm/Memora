# MEMORA 🧠

> *"AI that adapts to the person — not the other way around."*

**Smart India Hackathon (SIH) Problem Statement**:
**SIH26003 – AI-Based Cognitive Gaming and Memory Assistance Platform for Elderly Dementia Patients**

---

## 1. Project Overview & Medical Safety Positioning

**MEMORA** is an AI-powered cognitive gaming and memory assistance platform designed for elderly people experiencing dementia or memory-related difficulties, specially tailored for remote and rural areas of the **North-Eastern Region (NER) of India** with low internet connectivity.

### ⚠️ Strict Medical Positioning
- This platform is **NOT** a dementia diagnosis system.
- Game scores do **NOT** diagnose dementia, determine clinical dementia severity, or replace qualified medical professionals.
- The system tracks:
  - Game performance & accuracy
  - Response time (latency in ms)
  - Mistake patterns
  - Session frequency & engagement trends
- These metrics are used **strictly** to:
  1. Personalize cognitive game difficulty using transparent explainable rules.
  2. Provide caregivers with constructive, supportive trend overviews.
  3. Support memory recall through familiar photos, daily routines, and gentle reminders.

---

## 2. Key Features

1. **Elderly-Friendly Accessible UI (WCAG AAA Compliant)**:
   - High-contrast typography (22px - 36px)
   - Large touch targets ($\ge 64$px)
   - Calming healthcare color palette (Sage, Emerald, Ivory, Slate Navy)
   - Minimalist single-layer navigation with zero confusing menus.

2. **3 Core Cognitive Stimulation Games**:
   - **Game 1: Memory Match**: Observe $N$ familiar objects for 5 seconds with a gentle timer; recall and select them from 6 candidate items. Difficulty dynamically scales from Level 1 (3 items) to Level 4 (6 items).
   - **Game 2: Sequence Recall**: Observe a visual sequence (e.g., 🍎 $\rightarrow$ 🚗 $\rightarrow$ 🐘); reproduce the exact order using large visual touch buttons.
   - **Game 3: Culturally Familiar Object Recognition**: Everyday familiar Indian items (Chai Tea Cup, Clay Diya, Umbrella, Reading Book, Prayer Bell) with auditory prompts and spoken voice response.

3. **Explainable Rule-Based Adaptive AI Engine**:
   - `Accuracy >= 85%` with prompt response $\rightarrow$ Increments difficulty level. Explains: *"Difficulty increased because of consistently strong recent performance."*
   - `50% <= Accuracy < 85%` $\rightarrow$ Maintains difficulty. Explains: *"Difficulty maintained to build steady familiarity and confidence."*
   - `Accuracy < 50%` or high latency $\rightarrow$ Softens difficulty. Explains: *"Difficulty adjusted to support comfortable recall and confidence."* (Strictly neutral; **never** claims dementia is worsening).

4. **Offline-First Resilience**:
   - Full gameplay, reminders, memories, and GPS continue working when internet is disconnected.
   - Transactional local queue stores events with `sync_status: pending`.
   - Automatic batch synchronization (`POST /api/sync`) when connectivity returns.
   - Interactive `🟢 Online` / `🟠 Offline Mode` simulator button in top bar.

5. **Caregiver Monitoring Dashboard**:
   - Live overview of Mrs. Sharma's sessions, accuracy, and last active timestamp.
   - Cognitive domain breakdown: Memory (82%), Attention (74%), Sequence (68%), Recognition (88%).
   - Interactive Chart.js performance trends over the last 7 sessions.
   - Caregiver alerts center with neutral, actionable notices ("Please review").
   - Management tabs: Set Medicine/Hydration reminders, add personal family memories, set home GPS anchor.

6. **Personal Memory Assistance ("My Memories")**:
   - Flashcards of loved ones: Son Rahul (Guwahati), Daughter Priya (Pune), Shillong Summer Cottage, Morning Chai Cup.
   - Gentle familiarity questions.

7. **GPS & Home Assistance ("Find My Home")**:
   - Live browser Geolocation with Haversine distance computation to saved home.
   - Direction compass card and one-tap *"Call Rahul (Son)"*.

8. **Voice Assistant (TTS & STT)**:
   - Web Speech Synthesis with warm, slow pacing (0.85 rate) for elderly comfort.
   - Web Speech Recognition for spoken answers with resilient button fallback.

9. **Multilingual Support**:
   - Supports English, Hindi (हिन्दी), and North-Eastern Regional Assamese (অসমীয়া).

---

## 3. Technology Architecture

```
memora/
├── backend/
│   ├── app/
│   │   ├── main.py                # FastAPI app entry point & static mounting
│   │   ├── config.py              # App settings, paths, demo constants
│   │   ├── database.py            # SQLite database engine & queries
│   │   ├── schemas.py             # Pydantic validation schemas
│   │   ├── auth.py                # JWT authentication & RBAC
│   │   ├── adaptive_engine.py     # Explainable cognitive adaptive engine
│   │   ├── seed_data.py           # Pre-seeded Mrs. Sharma demo dataset
│   │   └── routers/               # Modular REST endpoints
│   │       ├── auth_router.py
│   │       ├── patient_router.py
│   │       ├── games_router.py
│   │       ├── reminders_router.py
│   │       ├── memories_router.py
│   │       ├── gps_router.py
│   │       ├── sync_router.py
│   │       └── dashboard_router.py
│   └── tests/
│       └── test_backend.py        # Automated unit tests
├── frontend/
│   ├── index.html                 # Unified single-page application
│   ├── css/
│   │   ├── style.css              # Accessible elderly theme
│   │   └── caregiver.css          # Clinical dashboard theme
│   └── js/
│       ├── app.js                 # App coordinator & SIH 16-step demo controller
│       ├── offline_store.js       # Offline storage & transactional sync queue
│       ├── voice_service.js       # Web Speech TTS and STT
│       ├── i18n.js                # Multilingual translations (EN, HI, AS)
│       ├── gps_service.js         # Geolocation & Haversine distance
│       ├── caregiver.js           # Caregiver dashboard & Chart.js trends
│       └── games/
│           ├── memory_match.js    # Game 1: Memory Match
│           ├── sequence_recall.js # Game 2: Sequence Recall
│           └── object_recog.js    # Game 3: Object Recognition
├── run_server.py                  # Single-command launcher
└── README.md
```

---

## 4. Running the Application

### Prerequisites
- Python 3.10+ installed
- Dependencies: `pip install fastapi uvicorn requests pyjwt python-multipart`

### Start Server
Run from the project directory (`memora` / `mindmate-ai`):
```powershell
python run_server.py
```
Open your browser at:
👉 **`http://127.0.0.1:8000/`**

API documentation is available at:
👉 **`http://127.0.0.1:8000/docs`**

---

## 5. Running Automated Tests

```powershell
python -m unittest discover -s backend/tests
```

All 5 unit tests verify database seeding, adaptive AI step-up, step-down, maintain rules, and cognitive metric aggregations.

---

## 6. The 16-Step SIH Hackathon Demo Walkthrough

The application includes a floating **SIH Guided Demo Bar** at the top of the screen that steps through the exact evaluation story:

1. **Step 1**: Caregiver logs in.
2. **Step 2**: Caregiver selects Mrs. Sharma.
3. **Step 3**: Caregiver sets medicine reminder, home location, and family memory.
4. **Step 4**: Patient opens the app.
5. **Step 5**: Patient sees *"Good Morning, Mrs. Sharma"* and today's status.
6. **Step 6**: Patient starts Memory Match.
7. **Step 7**: Patient scores 90%.
8. **Step 8**: Adaptive engine increments difficulty to Level 3 with explanation.
9. **Step 9**: Patient completes another activity.
10. **Step 10**: Turn internet OFF (`🟠 Offline Mode`).
11. **Step 11**: Patient completes a game offline; result stored in local queue.
12. **Step 12**: Turn internet ON (`🟢 Online`); auto-syncs pending items (`Sync complete ✓`).
13. **Step 13**: Caregiver dashboard live refreshes with the new synced game result.
14. **Step 14**: Show performance trend line charts (Accuracy & Response Time).
15. **Step 15**: Demonstrate medicine & hydration reminders.
16. **Step 16**: Demonstrate **FIND MY HOME** with GPS distance calculation and safe return guidance.
