import os
import sys
import uvicorn

# Ensure the backend directory is in the python path
BACKEND_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "backend"))
sys.path.insert(0, BACKEND_DIR)

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

if __name__ == "__main__":
    print("=" * 65)
    print("   MEMORA - SIH26003 Functional Prototype Launcher")
    print("   'AI that adapts to the person -- not the other way around.'")
    print("=" * 65)
    print(" * Backend API:        http://127.0.0.1:8000/api")
    print(" * Patient & Dashboard: http://127.0.0.1:8000/")
    print(" * API Documentation:  http://127.0.0.1:8000/docs")
    print("=" * 65)
    
    uvicorn.run("app.main:app", host="127.0.0.1", port=8000, reload=True, app_dir=BACKEND_DIR)
